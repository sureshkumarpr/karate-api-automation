# Kubernetes Cluster Analysis Tool

**Powered by Claude AI | Automated DevOps Diagnostics & RCA**

End-to-end Kubernetes cluster analysis tool that automatically collects diagnostics, runs them through Claude AI for intelligent analysis, and generates professional HTML reports. Perfect for production support teams, incident response, and DevOps troubleshooting.

![Python Version](https://img.shields.io/badge/Python-3.8%2B-blue)
![License](https://img.shields.io/badge/License-MIT-green)
![Status](https://img.shields.io/badge/Status-Production%20Ready-brightgreen)

## Features

✅ **Automated Diagnostics Collection**
- Pod logs and events
- Node metrics and status
- Cluster-wide resource usage
- Prometheus metrics
- OpenObserve error logs

✅ **Claude AI Analysis**
- Root cause analysis
- Severity assessment
- Immediate action recommendations
- Long-term resolution guidance
- Monitoring recommendations

✅ **Professional Reports**
- Beautiful HTML reports
- Downloadable & shareable
- Print-friendly design
- Mobile responsive

✅ **Enterprise Integrations**
- ServiceNow incident updates
- Email notifications
- Slack alerts
- GitHub issue creation
- AWS S3 upload
- Overwatch webhooks

✅ **REST API**
- Trigger analysis via HTTP
- Webhook endpoints
- Report management
- Status monitoring

## Quick Start

### Prerequisites

- Python 3.8+
- kubectl configured
- Azure CLI installed
- Claude API key
- Access to Kubernetes cluster

### Installation

```bash
# Clone repository
git clone https://github.com/yourusername/k8s-cluster-analyzer.git
cd k8s-cluster-analyzer

# Install dependencies
pip install -r requirements.txt

# Setup environment
cp .env.example .env
# Edit .env and add your credentials
```

### Basic Usage

```bash
# Run analysis
python run_cluster_analysis.py prod-cluster-1 payment-service my-pod-xyz

# Or with options
python run_cluster_analysis.py \
  --cluster prod-cluster-1 \
  --namespace payment-service \
  --pod my-pod-xyz \
  --incident-id INC0123456

# Via API
curl -X POST http://localhost:8000/api/v1/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "cluster_id": "prod-cluster-1",
    "namespace": "payment-service",
    "pod_name": "my-pod-xyz"
  }'
```

## Configuration

### Required Environment Variables

```env
# Claude API
CLAUDE_API_KEY=sk-ant-xxxxxxxxxxxxxxxxxxxxx

# Azure
AZURE_SUBSCRIPTION_ID=your-subscription-id
AZURE_RESOURCE_GROUP=your-resource-group

# Kubernetes
KUBECONFIG=/home/user/.kube/config

# Prometheus
PROMETHEUS_URL=http://prometheus:9090

# OpenObserve
OPENOBSERVE_URL=https://your-openobserve.com
OPENOBSERVE_TOKEN=your-token
```

### Optional Integrations

**ServiceNow**
```env
SERVICENOW_ENABLED=true
SERVICENOW_INSTANCE_URL=https://your-instance.service-now.com
SERVICENOW_USERNAME=your-username
SERVICENOW_PASSWORD=your-password
```

**Email Notifications**
```env
SMTP_ENABLED=true
SENDER_EMAIL=your-email@gmail.com
SENDER_PASSWORD=your-app-password
RECIPIENT_EMAILS=team@example.com
```

**AWS S3**
```env
AWS_BUCKET=your-bucket
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your-key
AWS_SECRET_ACCESS_KEY=your-secret
```

See `.env.example` for all configuration options.

## Architecture

```
Overwatch Alert / Manual Trigger
    ↓
run_cluster_analysis.py (Orchestration)
    ├── cluster_diagnostics.py (Collect data)
    │   ├── kubectl (Pod, Node, Events)
    │   ├── Prometheus (Metrics)
    │   └── OpenObserve (Logs)
    ├── generate_report.py (Claude Analysis)
    │   └── Claude API (Root Cause Analysis)
    └── Post-processing
        ├── Email Notification
        ├── ServiceNow Update
        └── S3 Upload

HTML Report Generated ✅
```

## API Endpoints

### Core Analysis

**POST /api/v1/analyze**
```bash
curl -X POST http://localhost:8000/api/v1/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "cluster_id": "prod-cluster-1",
    "namespace": "payment-service",
    "pod_name": "checkout-pod-xyz",
    "incident_id": "INC0123456"
  }'
```

**GET /api/v1/analyze/{cluster_id}/{namespace}/{pod_name}**
```bash
curl http://localhost:8000/api/v1/analyze/prod-cluster-1/payment-service/my-pod
```

### Health & Status

**GET /health**
```bash
curl http://localhost:8000/health
```

**GET /api/v1/status**
```bash
curl http://localhost:8000/api/v1/status
```

### Reports

**GET /api/v1/reports**
```bash
curl http://localhost:8000/api/v1/reports
```

### Webhooks

**POST /api/v1/webhook/overwatch**
```bash
curl -X POST http://localhost:8000/api/v1/webhook/overwatch \
  -H "Content-Type: application/json" \
  -d '{
    "alert_type": "kubepodcrash",
    "cluster_id": "prod-cluster-1",
    "namespace": "payment-service",
    "pod_name": "checkout-pod-xyz",
    "incident_id": "INC0123456"
  }'
```

**POST /api/v1/webhook/servicenow**
```bash
curl -X POST http://localhost:8000/api/v1/webhook/servicenow \
  -H "Content-Type: application/json" \
  -d '{
    "incident_id": "INC0123456",
    "short_description": "Pod crash detected"
  }'
```

## Running the API Server

```bash
# Development
python api_server.py

# Production (with Gunicorn)
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:8000 api_server:app
```

## Docker Deployment

```bash
# Build image
docker build -t k8s-cluster-analyzer .

# Run container
docker run -it \
  -e CLAUDE_API_KEY=sk-ant-xxx \
  -e AZURE_SUBSCRIPTION_ID=xxx \
  -v ~/.kube:/root/.kube \
  -v $(pwd)/cluster-reports:/app/cluster-reports \
  k8s-cluster-analyzer python run_cluster_analysis.py prod-cluster-1 default my-pod
```

## Examples

### Example 1: Manual CLI Analysis

```bash
# Analyze a crashed pod
python run_cluster_analysis.py prod-cluster-1 payment-service checkout-pod-abc123

# Output:
# ✅ Diagnostics collected: cluster-reports/prod-cluster-1/20240115_143022
# ✅ Report generated: cluster-reports/prod-cluster-1/20240115_143022/analysis-report.html
# ✅ Email sent to: devops-team@company.com
```

### Example 2: API Integration with Overwatch

```bash
# Configure Overwatch webhook to POST to:
http://your-server:8000/api/v1/webhook/overwatch

# Overwatch sends:
{
  "alert_type": "kubepodcrash",
  "cluster_id": "prod-cluster-1",
  "namespace": "payment-service",
  "pod_name": "checkout-pod-xyz"
}

# Tool automatically:
# 1. Collects diagnostics
# 2. Runs Claude analysis
# 3. Creates HTML report
# 4. Updates ServiceNow incident
# 5. Sends email notification
```

### Example 3: ServiceNow Integration

```bash
# Configure ServiceNow incident to trigger webhook:
POST http://your-server:8000/api/v1/webhook/servicenow

# Tool automatically updates the incident with analysis results
```

## Workflow Integration

### With Overwatch

1. Overwatch detects pod crash
2. POST to `/api/v1/webhook/overwatch`
3. Analysis runs automatically
4. Report attached to incident

### With ServiceNow

1. Incident created in ServiceNow
2. ServiceNow notifies analyzer via webhook
3. Analysis results posted back to incident
4. Link to HTML report added

### With GitHub Actions

```yaml
# .github/workflows/cluster-check.yml
name: Cluster Health Check

on:
  schedule:
    - cron: '0 */6 * * *'  # Every 6 hours

jobs:
  analyze:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run cluster analysis
        run: |
          python run_cluster_analysis.py prod-cluster-1 default test-pod
      - name: Upload report
        uses: actions/upload-artifact@v3
        with:
          name: cluster-report
          path: cluster-reports/
```

## Troubleshooting

### "Cannot connect to Kubernetes cluster"
```bash
# Verify kubeconfig
kubectl cluster-info

# Update credentials
az aks get-credentials --resource-group mygroup --name mycluster --overwrite-existing
```

### "Claude API key invalid"
```bash
# Check API key
echo $CLAUDE_API_KEY

# Generate new key at https://console.anthropic.com/
```

### "Prometheus/OpenObserve connection failed"
```bash
# Check connectivity
curl http://prometheus:9090/api/v1/query?query=up
curl https://your-openobserve.com/health
```

### "ServiceNow update failed"
```bash
# Test connection
python servicenow_integration.py

# Verify credentials in .env
# Check ServiceNow instance URL format
```

## Development

### Project Structure

```
k8s-cluster-analyzer/
├── run_cluster_analysis.py      # Main orchestration
├── cluster_diagnostics.py       # Diagnostics collection
├── generate_report.py           # Claude analysis & report
├── api_server.py                # REST API server
├── notify_via_email.py          # Email notifications
├── servicenow_integration.py    # ServiceNow integration
├── requirements.txt             # Python dependencies
├── .env.example                 # Configuration template
├── README.md                    # This file
└── cluster-reports/             # Generated reports
```

### Running Tests

```bash
# Test diagnostics collection
python -m pytest tests/test_diagnostics.py -v

# Test report generation
python -m pytest tests/test_reports.py -v

# Test API endpoints
python -m pytest tests/test_api.py -v

# Full test suite
pytest
```

### Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## GitHub Setup

### Initial Push to GitHub

```bash
# Initialize git repository (if not already done)
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit: Kubernetes Cluster Analysis Tool"

# Add remote
git remote add origin https://github.com/yourusername/k8s-cluster-analyzer.git

# Push to GitHub
git branch -M main
git push -u origin main
```

### GitHub Actions Workflow

Create `.github/workflows/ci.yml`:

```yaml
name: CI

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ['3.8', '3.9', '3.10', '3.11']
    
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: ${{ matrix.python-version }}
      - run: pip install -r requirements.txt
      - run: pytest
```

## Performance Metrics

Typical analysis time:

- Diagnostics collection: **30-60 seconds**
- Claude AI analysis: **5-15 seconds**
- Report generation: **2-5 seconds**
- Email/ServiceNow updates: **5-10 seconds**

**Total: 45-90 seconds**

## Security Considerations

- Store API keys in `.env` (never commit)
- Use IAM roles for Azure/AWS credentials
- Restrict API access with authentication
- Encrypt report storage
- Audit log all analysis runs
- HTTPS only for webhooks

## Roadmap

- [ ] Web UI dashboard
- [ ] Machine learning for pattern detection
- [ ] Multi-cluster analysis
- [ ] Custom alert rules
- [ ] Real-time monitoring dashboard
- [ ] Mobile app
- [ ] Advanced filtering and search
- [ ] Team collaboration features

## Support

### Documentation
- [Claude AI Documentation](https://docs.anthropic.com/)
- [Kubernetes Documentation](https://kubernetes.io/docs/)
- [Azure AKS Documentation](https://learn.microsoft.com/en-us/azure/aks/)

### Issues & Feedback
- GitHub Issues: [Report a bug](https://github.com/yourusername/k8s-cluster-analyzer/issues)
- Email: support@example.com
- Slack: #devops-tools

## License

MIT License - see [LICENSE](LICENSE) file for details

## Authors

- **Sureshkumar Ramasamy** - DevOps Engineer, TCS/Walmart
- Contributors welcome!

## Acknowledgments

- Anthropic for Claude AI API
- Kubernetes community
- Open source contributors

---

**Made with ❤️ for DevOps teams**

*Last updated: 2024-01-15*
