#!/usr/bin/env python3
"""
Setup script for Kubernetes Cluster Analysis Tool
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_file = Path(__file__).parent / "README.md"
long_description = ""
if readme_file.exists():
    with open(readme_file, encoding="utf-8") as f:
        long_description = f.read()

# Read requirements
requirements_file = Path(__file__).parent / "requirements.txt"
requirements = []
if requirements_file.exists():
    with open(requirements_file, encoding="utf-8") as f:
        requirements = [line.strip() for line in f if line.strip() and not line.startswith("#")]

setup(
    name="k8s-cluster-analyzer",
    version="1.0.0",
    description="Kubernetes Cluster Analysis Tool - Powered by Claude AI",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Sureshkumar Ramasamy",
    author_email="sureshkumar.ramasamy@walmart.com",
    url="https://github.com/yourusername/k8s-cluster-analyzer",
    license="MIT",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: System :: Systems Administration",
        "Topic :: System :: Monitoring",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=4.0",
            "black>=23.0",
            "flake8>=6.0",
            "mypy>=1.0",
        ],
        "api": [
            "flask>=2.3",
            "gunicorn>=21.0",
        ],
        "aws": [
            "boto3>=1.26",
        ],
    },
    entry_points={
        "console_scripts": [
            "cluster-analyzer=run_cluster_analysis:main",
            "cluster-api=api_server:run_server",
        ],
    },
    include_package_data=True,
    zip_safe=False,
    keywords=[
        "kubernetes",
        "devops",
        "monitoring",
        "incident-response",
        "ai",
        "claude",
        "troubleshooting",
    ],
    project_urls={
        "Bug Reports": "https://github.com/yourusername/k8s-cluster-analyzer/issues",
        "Documentation": "https://github.com/yourusername/k8s-cluster-analyzer/blob/main/README.md",
        "Source Code": "https://github.com/yourusername/k8s-cluster-analyzer",
    },
)
