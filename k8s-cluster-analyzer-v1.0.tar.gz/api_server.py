#!/usr/bin/env python3
"""
REST API Server for Cluster Analysis
Allows triggering analysis via HTTP requests
"""

import os
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Any
from dotenv import load_dotenv

try:
    from flask import Flask, request, jsonify
except ImportError:
    print("Flask not installed. Install with: pip install flask")
    exit(1)

from run_cluster_analysis import ClusterAnalysisPipeline

# Setup
load_dotenv()
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False

# Store active jobs
active_jobs = {}

class APIError(Exception):
    """Custom API error"""
    def __init__(self, message: str, status_code: int = 400):
        self.message = message
        self.status_code = status_code

@app.errorhandler(APIError)
def handle_api_error(error):
    """Handle custom API errors"""
    response = {
        "status": "error",
        "message": error.message,
        "timestamp": datetime.now().isoformat()
    }
    return jsonify(response), error.status_code

@app.before_request
def before_request():
    """Log incoming requests"""
    logger.info(f"{request.method} {request.path}")

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "version": "1.0.0"
    }), 200

@app.route('/api/v1/analyze', methods=['POST'])
def analyze_cluster():
    """
    Trigger cluster analysis
    
    Request body:
    {
        "cluster_id": "prod-cluster-1",
        "namespace": "payment-service",
        "pod_name": "checkout-pod-xyz",
        "incident_id": "INC0123456" (optional)
    }
    """
    try:
        # Validate request
        if not request.is_json:
            raise APIError("Request must be JSON", 400)
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['cluster_id', 'namespace', 'pod_name']
        for field in required_fields:
            if field not in data:
                raise APIError(f"Missing required field: {field}", 400)
        
        cluster_id = data['cluster_id']
        namespace = data['namespace']
        pod_name = data['pod_name']
        incident_id = data.get('incident_id')
        
        logger.info(f"Starting analysis: {cluster_id}/{namespace}/{pod_name}")
        
        # Run pipeline
        pipeline = ClusterAnalysisPipeline(
            cluster_id=cluster_id,
            namespace=namespace,
            pod_name=pod_name
        )
        
        success = pipeline.run()
        
        if not success:
            raise APIError("Analysis pipeline failed", 500)
        
        # Prepare response
        response = {
            "status": "success",
            "message": "Cluster analysis completed",
            "cluster_id": cluster_id,
            "namespace": namespace,
            "pod_name": pod_name,
            "diagnostics_dir": pipeline.diagnostics_dir,
            "report_path": pipeline.report_path,
            "timestamp": datetime.now().isoformat()
        }
        
        logger.info(f"Analysis complete: {response['report_path']}")
        
        return jsonify(response), 200
        
    except APIError:
        raise
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        raise APIError(f"Internal server error: {str(e)}", 500)

@app.route('/api/v1/analyze/<cluster_id>/<namespace>/<pod_name>', methods=['GET'])
def analyze_cluster_get(cluster_id: str, namespace: str, pod_name: str):
    """
    Trigger analysis via GET request
    
    Usage: GET /api/v1/analyze/prod-cluster-1/payment-service/checkout-pod-xyz
    """
    try:
        logger.info(f"Starting analysis: {cluster_id}/{namespace}/{pod_name}")
        
        pipeline = ClusterAnalysisPipeline(
            cluster_id=cluster_id,
            namespace=namespace,
            pod_name=pod_name
        )
        
        success = pipeline.run()
        
        if not success:
            raise APIError("Analysis pipeline failed", 500)
        
        response = {
            "status": "success",
            "message": "Cluster analysis completed",
            "cluster_id": cluster_id,
            "namespace": namespace,
            "pod_name": pod_name,
            "diagnostics_dir": pipeline.diagnostics_dir,
            "report_path": pipeline.report_path,
            "timestamp": datetime.now().isoformat()
        }
        
        return jsonify(response), 200
        
    except APIError:
        raise
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        raise APIError(f"Internal server error: {str(e)}", 500)

@app.route('/api/v1/status', methods=['GET'])
def get_status():
    """Get system status and configuration"""
    return jsonify({
        "status": "operational",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat(),
        "configuration": {
            "claude_api_configured": bool(os.getenv("CLAUDE_API_KEY")),
            "azure_configured": bool(os.getenv("AZURE_SUBSCRIPTION_ID")),
            "prometheus_configured": bool(os.getenv("PROMETHEUS_URL")),
            "openobserve_configured": bool(os.getenv("OPENOBSERVE_URL")),
            "servicenow_configured": bool(os.getenv("SERVICENOW_INSTANCE_URL")),
            "email_configured": os.getenv("SMTP_ENABLED") == "true"
        }
    }), 200

@app.route('/api/v1/reports', methods=['GET'])
def list_reports():
    """List generated reports"""
    try:
        reports_dir = Path("cluster-reports")
        
        if not reports_dir.exists():
            return jsonify({
                "status": "success",
                "reports": [],
                "total": 0
            }), 200
        
        reports = []
        for report_file in reports_dir.rglob("analysis-report.html"):
            reports.append({
                "path": str(report_file),
                "size_mb": report_file.stat().st_size / (1024 * 1024),
                "created": datetime.fromtimestamp(report_file.stat().st_ctime).isoformat()
            })
        
        return jsonify({
            "status": "success",
            "reports": sorted(reports, key=lambda x: x['created'], reverse=True),
            "total": len(reports)
        }), 200
        
    except Exception as e:
        logger.error(f"Error listing reports: {str(e)}")
        raise APIError(f"Error listing reports: {str(e)}", 500)

@app.route('/api/v1/webhook/overwatch', methods=['POST'])
def webhook_overwatch():
    """
    Overwatch webhook endpoint
    Triggered when Overwatch detects an alert
    
    Request body:
    {
        "alert_type": "kubepodcrash",
        "cluster_id": "prod-cluster-1",
        "namespace": "payment-service",
        "pod_name": "checkout-pod-xyz",
        "incident_id": "INC0123456"
    }
    """
    try:
        data = request.get_json()
        
        cluster_id = data.get('cluster_id')
        namespace = data.get('namespace')
        pod_name = data.get('pod_name')
        incident_id = data.get('incident_id')
        alert_type = data.get('alert_type', 'unknown')
        
        if not all([cluster_id, namespace, pod_name]):
            raise APIError("Missing required fields: cluster_id, namespace, pod_name", 400)
        
        logger.info(f"Overwatch alert received: {alert_type}")
        logger.info(f"Cluster: {cluster_id}, Pod: {pod_name}, Namespace: {namespace}")
        
        # Run analysis
        pipeline = ClusterAnalysisPipeline(
            cluster_id=cluster_id,
            namespace=namespace,
            pod_name=pod_name
        )
        
        success = pipeline.run()
        
        if success:
            response = {
                "status": "success",
                "message": "Analysis triggered by Overwatch alert",
                "alert_type": alert_type,
                "incident_id": incident_id,
                "report_path": pipeline.report_path
            }
            status_code = 200
        else:
            response = {
                "status": "error",
                "message": "Analysis pipeline failed"
            }
            status_code = 500
        
        response["timestamp"] = datetime.now().isoformat()
        return jsonify(response), status_code
        
    except APIError:
        raise
    except Exception as e:
        logger.error(f"Webhook error: {str(e)}")
        raise APIError(f"Webhook processing error: {str(e)}", 500)

@app.route('/api/v1/webhook/servicenow', methods=['POST'])
def webhook_servicenow():
    """
    ServiceNow webhook endpoint
    Triggered when ServiceNow creates an incident
    """
    try:
        data = request.get_json()
        
        incident_id = data.get('incident_id')
        short_desc = data.get('short_description', '')
        
        logger.info(f"ServiceNow incident webhook: {incident_id}")
        
        # Extract cluster info from description if available
        # This is a simplified example
        
        response = {
            "status": "success",
            "message": "ServiceNow incident received",
            "incident_id": incident_id,
            "timestamp": datetime.now().isoformat()
        }
        
        return jsonify(response), 200
        
    except Exception as e:
        logger.error(f"ServiceNow webhook error: {str(e)}")
        raise APIError(f"Webhook error: {str(e)}", 500)

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({
        "status": "error",
        "message": "Endpoint not found",
        "path": request.path
    }), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    return jsonify({
        "status": "error",
        "message": "Internal server error"
    }), 500

def run_server():
    """Start the API server"""
    host = os.getenv("API_HOST", "0.0.0.0")
    port = int(os.getenv("API_PORT", "8000"))
    debug = os.getenv("API_DEBUG", "false").lower() == "true"
    
    logger.info(f"Starting Cluster Analysis API Server")
    logger.info(f"Listening on {host}:{port}")
    logger.info(f"Health check: GET http://{host}:{port}/health")
    logger.info(f"API docs: GET http://{host}:{port}/api/v1/status")
    
    app.run(host=host, port=port, debug=debug)

if __name__ == "__main__":
    run_server()
