# Complete Deployment & Setup Guide

**Kubernetes Cluster Analysis Tool v1.0**

Complete guide for installation, configuration, and deployment. All files and instructions needed for production deployment.

---

## 📋 Table of Contents

1. [System Requirements](#system-requirements)
2. [Installation](#installation)
3. [Configuration](#configuration)
4. [Running Analysis](#running-analysis)
5. [API Server Setup](#api-server-setup)
6. [Docker Deployment](#docker-deployment)
7. [Integration Setup](#integration-setup)
8. [Troubleshooting](#troubleshooting)

---

## System Requirements

### Software Requirements

- **Python**: 3.8 or higher
- **kubectl**: Latest version
- **Azure CLI**: Latest version
- **Docker** (optional): For containerized deployment
- **Git**: For repository management

### Hardware Requirements

- **CPU**: 2+ cores
- **Memory**: 2GB+ RAM
- **Disk**: 10GB+ for reports
- **Network**: HTTPS connectivity required

### Cloud Access

- Azure subscription with AKS cluster
- Kubernetes cluster access
- Prometheus/OpenObserve access (for metrics)

### API Keys & Credentials

- **Claude API Key**: Get from https://console.anthropic.com/
- **Azure credentials**: Service Principal or User account
- **Kubernetes credentials**: kubeconfig file
- **Prometheus/OpenObserve tokens** (if applicable)
- **ServiceNow credentials** (if integrating)

---

## Installation

### Step 1: Clone Repository

```bash
# Clone from GitHub
git clone https://github.com/yourusername/k8s-cluster-analyzer.git
cd k8s-cluster-analyzer

# Or initialize locally
mkdir k8s-cluster-analyzer
cd k8s-cluster-analyzer
git init
```

### Step 2: Create Python Virtual Environment

```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Linux/Mac:
source venv/bin/activate

# On Windows:
venv\Scripts\activate

# Verify activation
which python  # Should show venv path
```

### Step 3: Install Dependencies

```bash
# Upgrade pip
pip install --upgrade pip setuptools wheel

# Install requirements
pip install -r requirements.txt

# Verify installation
python -c "import anthropic; print(anthropic.__version__)"
```

### Step 4: Install Azure CLI

```bash
# Linux/Mac
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash

# Or with Homebrew (Mac)
brew install azure-cli

# Windows (using Chocolatey)
choco install azure-cli

# Verify
az --version
```

### Step 5: Install kubectl

```bash
# Download kubectl
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"

# Make executable
chmod +x kubectl
sudo mv kubectl /usr/local/bin/

# Verify
kubectl version --client
```

---

## Configuration

### Step 1: Create Environment File

```bash
# Copy environment template
cp .env.example .env

# Edit environment file
nano .env
# or
vi .env
# or use your editor
```

### Step 2: Configure Claude API

```bash
# Get API key from: https://console.anthropic.com/account/keys

# Add to .env
CLAUDE_API_KEY=sk-ant-xxxxxxxxxxxxxxxxxxxxx
```

### Step 3: Configure Azure

```bash
# Login to Azure
az login

# List subscriptions
az account list

# Set subscription
az account set --subscription "YOUR-SUBSCRIPTION-ID"

# Add to .env
AZURE_SUBSCRIPTION_ID=your-subscription-id
AZURE_RESOURCE_GROUP=your-resource-group
AZURE_TENANT_ID=your-tenant-id
```

### Step 4: Configure Kubernetes

```bash
# Get AKS credentials
az aks get-credentials --resource-group YOUR-RG --name YOUR-CLUSTER

# Verify connection
kubectl cluster-info

# Add to .env
KUBECONFIG=/home/user/.kube/config
```

### Step 5: Configure Monitoring Tools

**Prometheus:**
```bash
# Find Prometheus URL
kubectl get svc -n prometheus

# Add to .env
PROMETHEUS_URL=http://prometheus:9090
```

**OpenObserve:**
```bash
# Get OpenObserve URL and token from your setup
# Add to .env
OPENOBSERVE_URL=https://your-openobserve.com
OPENOBSERVE_TOKEN=your-token
```

### Step 6: Configure Email (Optional)

```bash
# For Gmail, use app-specific password
# 1. Enable 2FA on Google Account
# 2. Generate app password at: https://myaccount.google.com/apppasswords

# Add to .env
SMTP_ENABLED=true
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SENDER_EMAIL=your-email@gmail.com
SENDER_PASSWORD=your-app-password
RECIPIENT_EMAILS=team1@example.com,team2@example.com
```

### Step 7: Configure ServiceNow (Optional)

```bash
# Get credentials from your ServiceNow admin

# Add to .env
SERVICENOW_ENABLED=true
SERVICENOW_INSTANCE_URL=https://your-instance.service-now.com
SERVICENOW_USERNAME=your-username
SERVICENOW_PASSWORD=your-password
SERVICENOW_TABLE=incident
SERVICENOW_ASSIGN_GROUP=Kubernetes Team
```

### Step 8: Test Configuration

```bash
# Test email configuration
python notify_via_email.py

# Test ServiceNow configuration
python servicenow_integration.py

# Test cluster connectivity
kubectl get nodes

# Test Claude API
python -c "
import os
from anthropic import Anthropic
client = Anthropic(api_key=os.getenv('CLAUDE_API_KEY'))
print('✅ Claude API is accessible')
"
```

---

## Running Analysis

### Option 1: Command Line (Direct)

```bash
# Activate virtual environment
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Run analysis
python run_cluster_analysis.py prod-cluster-1 default my-pod-xyz

# With verbose logging
python run_cluster_analysis.py \
  --cluster prod-cluster-1 \
  --namespace default \
  --pod my-pod-xyz \
  --verbose

# With ServiceNow integration
python run_cluster_analysis.py \
  prod-cluster-1 default my-pod-xyz \
  --incident-id INC0123456
```

### Option 2: Command Line (Using Entry Point)

```bash
# Install in development mode
pip install -e .

# Run directly
cluster-analyzer prod-cluster-1 default my-pod-xyz
```

### Option 3: Python Script Import

```python
from run_cluster_analysis import ClusterAnalysisPipeline

pipeline = ClusterAnalysisPipeline(
    cluster_id="prod-cluster-1",
    namespace="default",
    pod_name="my-pod-xyz"
)

success = pipeline.run()
print(f"Report: {pipeline.report_path}")
```

### Expected Output

```
════════════════════════════════════════════════════════════════════
🚀 KUBERNETES CLUSTER ANALYSIS TOOL v1.0
════════════════════════════════════════════════════════════════════

[1/3] 📊 Collecting Cluster Diagnostics
─────────────────────────────────────────────────────────────────
Cluster: prod-cluster-1
Namespace: default
Pod: my-pod-xyz
Connecting to cluster...
✅ Diagnostics collected: cluster-reports/prod-cluster-1/20240115_143022

[2/3] 🤖 Claude AI Analysis
─────────────────────────────────────────────────────────────────
Sending diagnostics to Claude for analysis...
✅ Report generated: cluster-reports/prod-cluster-1/20240115_143022/analysis-report.html

[3/3] 📤 Post-Processing & Notifications
─────────────────────────────────────────────────────────────────
✅ Email sent to: team@example.com
✅ ServiceNow updated: INC0123456

════════════════════════════════════════════════════════════════════
✨ ANALYSIS COMPLETE
════════════════════════════════════════════════════════════════════
📄 Report: cluster-reports/prod-cluster-1/20240115_143022/analysis-report.html
Next steps:
  1. Open the HTML report in your browser
  2. Review root cause analysis
  3. Execute recommended actions
  4. Update incident ticket
  5. Monitor the pod after remediation
  6. Share findings with team
════════════════════════════════════════════════════════════════════
```

---

## API Server Setup

### Option 1: Development Server

```bash
# Activate virtual environment
source venv/bin/activate

# Run development server
python api_server.py

# Output:
# Starting Cluster Analysis API Server
# Listening on 0.0.0.0:8000
# Health check: GET http://0.0.0.0:8000/health
# API docs: GET http://0.0.0.0:8000/api/v1/status
```

### Option 2: Production Server (Gunicorn)

```bash
# Install Gunicorn
pip install gunicorn

# Run with Gunicorn
gunicorn -w 4 -b 0.0.0.0:8000 api_server:app

# With configuration file
gunicorn -c gunicorn_config.py api_server:app
```

### Option 3: Systemd Service (Linux)

Create `/etc/systemd/system/cluster-analyzer.service`:

```ini
[Unit]
Description=Kubernetes Cluster Analysis API Server
After=network.target

[Service]
Type=notify
User=devops
WorkingDirectory=/opt/k8s-cluster-analyzer
Environment="PATH=/opt/k8s-cluster-analyzer/venv/bin"
EnvironmentFile=/opt/k8s-cluster-analyzer/.env
ExecStart=/opt/k8s-cluster-analyzer/venv/bin/gunicorn -w 4 -b 127.0.0.1:8000 api_server:app
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl daemon-reload
sudo systemctl enable cluster-analyzer
sudo systemctl start cluster-analyzer
sudo systemctl status cluster-analyzer
```

### Step 4: Test API

```bash
# Health check
curl http://localhost:8000/health

# Get status
curl http://localhost:8000/api/v1/status

# Trigger analysis
curl -X POST http://localhost:8000/api/v1/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "cluster_id": "prod-cluster-1",
    "namespace": "default",
    "pod_name": "my-pod-xyz"
  }'

# List reports
curl http://localhost:8000/api/v1/reports
```

---

## Docker Deployment

### Step 1: Build Docker Image

```bash
# Build image
docker build -t k8s-cluster-analyzer:1.0 .

# Verify build
docker images | grep cluster-analyzer
```

### Step 2: Run Container (CLI Mode)

```bash
# Run analysis in container
docker run -it \
  -e CLAUDE_API_KEY=sk-ant-xxx \
  -e AZURE_SUBSCRIPTION_ID=xxx \
  -v ~/.kube:/root/.kube:ro \
  -v $(pwd)/cluster-reports:/app/cluster-reports \
  k8s-cluster-analyzer:1.0 \
  python run_cluster_analysis.py prod-cluster-1 default my-pod-xyz
```

### Step 3: Run Container (API Mode)

```bash
# Run API server in container
docker run -d \
  -e CLAUDE_API_KEY=sk-ant-xxx \
  -e AZURE_SUBSCRIPTION_ID=xxx \
  -v ~/.kube:/root/.kube:ro \
  -v $(pwd)/cluster-reports:/app/cluster-reports \
  -p 8000:8000 \
  --name cluster-analyzer \
  k8s-cluster-analyzer:1.0 \
  python api_server.py

# Check logs
docker logs cluster-analyzer

# Stop container
docker stop cluster-analyzer
```

### Step 4: Docker Compose

```bash
# Create .env file for Docker Compose
cat > .docker.env << EOF
CLAUDE_API_KEY=sk-ant-xxx
AZURE_SUBSCRIPTION_ID=xxx
# ... other env variables
EOF

# Run with Docker Compose
docker-compose --env-file .docker.env up -d

# View logs
docker-compose logs -f cluster-analyzer

# Stop services
docker-compose down
```

### Step 5: Push to Docker Registry (Optional)

```bash
# Tag image
docker tag k8s-cluster-analyzer:1.0 yourusername/k8s-cluster-analyzer:1.0

# Push to Docker Hub
docker push yourusername/k8s-cluster-analyzer:1.0
```

---

## Integration Setup

### Overwatch Integration

1. In Overwatch, create webhook:
   ```
   POST http://your-server:8000/api/v1/webhook/overwatch
   ```

2. Test webhook:
   ```bash
   curl -X POST http://localhost:8000/api/v1/webhook/overwatch \
     -H "Content-Type: application/json" \
     -d '{
       "alert_type": "kubepodcrash",
       "cluster_id": "prod-cluster-1",
       "namespace": "default",
       "pod_name": "test-pod"
     }'
   ```

### ServiceNow Webhook

1. In ServiceNow, create business rule:
   - Event: Incident created
   - Action: Send webhook to `http://your-server:8000/api/v1/webhook/servicenow`

2. Incident automatically updates with analysis results

### GitHub Integration

1. Create GitHub token: https://github.com/settings/tokens
2. Add to .env:
   ```
   GITHUB_TOKEN=ghp_xxxxxxxxxxxxx
   ```

---

## Troubleshooting

### "Cannot connect to cluster"

```bash
# Verify kubeconfig
kubectl cluster-info

# Update credentials
az aks get-credentials --resource-group RG --name CLUSTER --overwrite-existing

# Check permissions
kubectl auth can-i get pods --all-namespaces
```

### "Claude API key invalid"

```bash
# Verify key format
echo $CLAUDE_API_KEY

# Generate new key at https://console.anthropic.com/account/keys
```

### "Prometheus connection failed"

```bash
# Check Prometheus service
kubectl get svc -n prometheus

# Port forward for testing
kubectl port-forward -n prometheus svc/prometheus 9090:9090

# Test connection
curl http://localhost:9090/api/v1/query?query=up
```

### "ServiceNow authentication failed"

```bash
# Test connection
python servicenow_integration.py

# Verify credentials in .env
# Check instance URL format (https://your-instance.service-now.com)
```

### Performance Issues

```bash
# Monitor system resources
top
df -h
ps aux | grep python

# Check logs
tail -f logs/cluster-analysis.log

# Increase log level
LOG_LEVEL=DEBUG python run_cluster_analysis.py ...
```

---

## Monitoring & Logging

### View Logs

```bash
# CLI analysis logs
tail -f logs/cluster-analysis.log

# API server logs
docker-compose logs -f cluster-analyzer

# Systemd service logs
sudo journalctl -u cluster-analyzer -f
```

### Health Monitoring

```bash
# API health check
curl http://localhost:8000/health

# System resources
top
docker stats

# Disk usage
du -sh cluster-reports/
```

---

## Security Best Practices

1. **API Keys**: Store in .env (not in code)
2. **Credentials**: Use environment variables
3. **HTTPS**: Use HTTPS for API endpoints
4. **Authentication**: Implement API key authentication for webhooks
5. **Logs**: Rotate logs regularly
6. **Backups**: Back up reports to S3

---

## Next Steps

1. ✅ Installation complete
2. ✅ Configuration complete
3. ⏭️ Run first analysis
4. ⏭️ Set up API server
5. ⏭️ Configure integrations
6. ⏭️ Monitor in production

---

## Support & Documentation

- Main README: `README.md`
- GitHub Setup: `GITHUB_SETUP.md`
- Claude Docs: https://docs.anthropic.com/
- Kubernetes Docs: https://kubernetes.io/docs/
- Azure AKS Docs: https://learn.microsoft.com/en-us/azure/aks/

---

**Deployment complete! 🎉**

For questions or issues, contact your DevOps team or create an issue on GitHub.
