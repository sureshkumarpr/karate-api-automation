#!/usr/bin/env python3
"""
Main Orchestration Script for Cluster Analysis
Coordinates diagnostics collection, Claude analysis, and report generation
"""

import os
import sys
import argparse
import subprocess
from pathlib import Path
from datetime import datetime
import logging
from dotenv import load_dotenv
from typing import Optional

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

class ClusterAnalysisPipeline:
    def __init__(self, cluster_id: str, namespace: str, pod_name: str, output_dir: Optional[str] = None):
        self.cluster_id = cluster_id
        self.namespace = namespace
        self.pod_name = pod_name
        self.output_dir = output_dir or "cluster-reports"
        self.diagnostics_dir = None
        self.report_path = None
        
    def print_banner(self):
        """Print startup banner"""
        banner = """
════════════════════════════════════════════════════════════════════
🚀 KUBERNETES CLUSTER ANALYSIS TOOL v1.0
════════════════════════════════════════════════════════════════════

Powered by Claude AI Analysis Engine
Anthropic API Integration for Production Support

════════════════════════════════════════════════════════════════════
        """
        print(banner)
    
    def print_step(self, step_num: int, total: int, title: str):
        """Print step header"""
        print(f"\n[{step_num}/{total}] {title}")
        print("─" * 60)
    
    def run_step_1_collect_diagnostics(self):
        """Step 1: Collect cluster diagnostics"""
        self.print_step(1, 3, "📊 Collecting Cluster Diagnostics")
        
        try:
            logger.info(f"Cluster: {self.cluster_id}")
            logger.info(f"Namespace: {self.namespace}")
            logger.info(f"Pod: {self.pod_name}")
            
            # Import and run diagnostics
            from cluster_diagnostics import ClusterDiagnostics
            
            diagnostics = ClusterDiagnostics(
                self.cluster_id,
                self.namespace,
                self.pod_name
            )
            
            self.diagnostics_dir = diagnostics.run()
            
            logger.info(f"✅ Diagnostics collected successfully")
            logger.info(f"📁 Location: {self.diagnostics_dir}")
            
            return True
        except Exception as e:
            logger.error(f"❌ Diagnostics collection failed: {str(e)}")
            return False
    
    def run_step_2_claude_analysis(self):
        """Step 2: Generate report with Claude analysis"""
        self.print_step(2, 3, "🤖 Claude AI Analysis")
        
        if not self.diagnostics_dir:
            logger.error("❌ No diagnostics directory found")
            return False
        
        try:
            logger.info("Sending diagnostics to Claude for analysis...")
            
            # Import and run report generation
            from generate_report import ReportGenerator
            
            generator = ReportGenerator(
                self.diagnostics_dir,
                self.cluster_id,
                self.namespace,
                self.pod_name
            )
            
            self.report_path = generator.run()
            
            logger.info(f"✅ Report generated successfully")
            logger.info(f"📄 Location: {self.report_path}")
            
            return True
        except Exception as e:
            logger.error(f"❌ Report generation failed: {str(e)}")
            return False
    
    def run_step_3_post_processing(self):
        """Step 3: Post-processing and notifications"""
        self.print_step(3, 3, "📤 Post-Processing & Notifications")
        
        if not self.report_path:
            logger.error("❌ No report file found")
            return False
        
        try:
            # Upload to S3 (optional)
            if os.getenv("AWS_BUCKET"):
                self.upload_to_s3()
            
            # Send email notification
            if os.getenv("SMTP_ENABLED") == "true":
                self.send_email_notification()
            
            # Update ServiceNow (optional)
            if os.getenv("SERVICENOW_ENABLED") == "true":
                self.update_servicenow()
            
            logger.info("✅ Post-processing complete")
            return True
        except Exception as e:
            logger.warning(f"⚠️  Post-processing error (non-critical): {str(e)}")
            return True  # Non-critical
    
    def upload_to_s3(self):
        """Upload report to S3"""
        try:
            import boto3
            
            aws_bucket = os.getenv("AWS_BUCKET")
            aws_region = os.getenv("AWS_REGION", "us-east-1")
            
            logger.info(f"Uploading to S3: {aws_bucket}")
            
            s3_client = boto3.client('s3', region_name=aws_region)
            
            report_file = Path(self.report_path)
            s3_key = f"cluster-reports/{self.cluster_id}/{report_file.name}"
            
            s3_client.upload_file(str(report_file), aws_bucket, s3_key)
            
            s3_url = f"https://{aws_bucket}.s3.{aws_region}.amazonaws.com/{s3_key}"
            logger.info(f"✅ Report uploaded to S3: {s3_url}")
            
        except Exception as e:
            logger.warning(f"Could not upload to S3: {str(e)}")
    
    def send_email_notification(self):
        """Send email notification with report link"""
        try:
            from notify_via_email import EmailNotifier
            
            logger.info("Sending email notification...")
            
            notifier = EmailNotifier()
            notifier.send_report_notification(
                cluster_id=self.cluster_id,
                pod_name=self.pod_name,
                namespace=self.namespace,
                report_path=self.report_path
            )
            
            logger.info("✅ Email sent successfully")
        except Exception as e:
            logger.warning(f"Could not send email: {str(e)}")
    
    def update_servicenow(self):
        """Update ServiceNow incident with report"""
        try:
            incident_id = os.getenv("SERVICENOW_INCIDENT_ID")
            if not incident_id:
                logger.warning("SERVICENOW_INCIDENT_ID not set, skipping update")
                return
            
            from servicenow_integration import ServiceNowClient
            
            logger.info(f"Updating ServiceNow incident: {incident_id}")
            
            client = ServiceNowClient()
            client.update_incident(incident_id, self.report_path)
            
            logger.info("✅ ServiceNow updated successfully")
        except Exception as e:
            logger.warning(f"Could not update ServiceNow: {str(e)}")
    
    def print_summary(self, success: bool):
        """Print final summary"""
        print("\n" + "=" * 60)
        
        if success:
            print("✅ ANALYSIS COMPLETE")
            print("=" * 60)
            print(f"\n📊 Diagnostics Directory:")
            print(f"   {self.diagnostics_dir}")
            print(f"\n📄 Report File:")
            print(f"   {self.report_path}")
            print(f"\n📋 Next Steps:")
            print(f"   1. Open the HTML report in your browser")
            print(f"   2. Review the Root Cause Analysis section")
            print(f"   3. Execute the recommended Immediate Actions")
            print(f"   4. Update your incident ticket (ServiceNow/Jira)")
            print(f"   5. Monitor the pod after remediation")
            print(f"   6. Share findings with your team")
        else:
            print("❌ ANALYSIS FAILED")
            print("=" * 60)
            print(f"\n⚠️  Check logs above for error details")
        
        print("\n" + "=" * 60 + "\n")
    
    def run(self) -> bool:
        """Execute complete pipeline"""
        self.print_banner()
        
        # Step 1: Diagnostics
        if not self.run_step_1_collect_diagnostics():
            self.print_summary(False)
            return False
        
        # Step 2: Claude Analysis
        if not self.run_step_2_claude_analysis():
            self.print_summary(False)
            return False
        
        # Step 3: Post-processing
        self.run_step_3_post_processing()
        
        self.print_summary(True)
        return True

def create_arg_parser():
    """Create command line argument parser"""
    parser = argparse.ArgumentParser(
        description='Kubernetes Cluster Analysis Tool - Powered by Claude AI',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s prod-cluster-1 payment-service my-pod-xyz
  %(prog)s --cluster my-cluster --namespace default --pod mypod
  %(prog)s -c prod-1 -n kube-system -p coredns-xyz --output /tmp/reports

For more information, visit: https://github.com/yourusername/k8s-cluster-analyzer
        """
    )
    
    parser.add_argument(
        'cluster_id',
        nargs='?',
        help='Kubernetes cluster ID/name'
    )
    
    parser.add_argument(
        'namespace',
        nargs='?',
        help='Kubernetes namespace'
    )
    
    parser.add_argument(
        'pod_name',
        nargs='?',
        help='Pod name to analyze'
    )
    
    parser.add_argument(
        '-c', '--cluster',
        dest='cluster_id_opt',
        help='Cluster ID (alternative to positional argument)'
    )
    
    parser.add_argument(
        '-n', '--namespace',
        dest='namespace_opt',
        help='Namespace (alternative to positional argument)'
    )
    
    parser.add_argument(
        '-p', '--pod',
        dest='pod_name_opt',
        help='Pod name (alternative to positional argument)'
    )
    
    parser.add_argument(
        '-o', '--output',
        dest='output_dir',
        help='Output directory for reports (default: cluster-reports)'
    )
    
    parser.add_argument(
        '--incident-id',
        dest='incident_id',
        help='ServiceNow incident ID to update'
    )
    
    parser.add_argument(
        '-v', '--verbose',
        action='store_true',
        help='Enable verbose logging'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version='%(prog)s 1.0.0'
    )
    
    return parser

def main():
    """Main entry point"""
    parser = create_arg_parser()
    args = parser.parse_args()
    
    # Get values from args (prefer optional arguments)
    cluster_id = args.cluster_id_opt or args.cluster_id
    namespace = args.namespace_opt or args.namespace
    pod_name = args.pod_name_opt or args.pod_name
    
    # Validate required arguments
    if not cluster_id or not namespace or not pod_name:
        parser.print_help()
        print("\n❌ Error: Missing required arguments")
        print("\nUsage: run_cluster_analysis.py <cluster_id> <namespace> <pod_name>")
        sys.exit(1)
    
    # Set verbose logging if requested
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Set incident ID if provided
    if args.incident_id:
        os.environ['SERVICENOW_INCIDENT_ID'] = args.incident_id
    
    # Run pipeline
    pipeline = ClusterAnalysisPipeline(
        cluster_id=cluster_id,
        namespace=namespace,
        pod_name=pod_name,
        output_dir=args.output_dir
    )
    
    success = pipeline.run()
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
