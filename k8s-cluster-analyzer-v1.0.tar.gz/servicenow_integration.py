#!/usr/bin/env python3
"""
ServiceNow Integration
Updates incidents with cluster analysis reports
"""

import os
import json
import requests
from pathlib import Path
from datetime import datetime
import logging
from dotenv import load_dotenv
from typing import Dict, Any, Optional

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

load_dotenv()

class ServiceNowClient:
    def __init__(self):
        self.instance_url = os.getenv("SERVICENOW_INSTANCE_URL")
        self.username = os.getenv("SERVICENOW_USERNAME")
        self.password = os.getenv("SERVICENOW_PASSWORD")
        self.table_name = os.getenv("SERVICENOW_TABLE", "incident")
        
        if not all([self.instance_url, self.username, self.password]):
            logger.warning("ServiceNow credentials not fully configured")
            self.enabled = False
        else:
            self.enabled = True
            self.auth = (self.username, self.password)
            self.headers = {
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
    
    def get_incident(self, incident_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve incident details from ServiceNow"""
        
        if not self.enabled:
            logger.warning("ServiceNow not enabled")
            return None
        
        try:
            url = f"{self.instance_url}/api/now/table/{self.table_name}/{incident_id}"
            
            logger.info(f"Fetching incident: {incident_id}")
            
            response = requests.get(url, auth=self.auth, headers=self.headers, timeout=30)
            response.raise_for_status()
            
            result = response.json()
            logger.info(f"✅ Incident retrieved: {incident_id}")
            
            return result.get('result', {})
            
        except Exception as e:
            logger.error(f"Error retrieving incident: {str(e)}")
            return None
    
    def update_incident(self, incident_id: str, report_path: str, 
                       state: str = "in_progress", work_notes: str = "") -> bool:
        """Update incident with analysis report"""
        
        if not self.enabled:
            logger.warning("ServiceNow not enabled")
            return False
        
        try:
            # Read report file
            if not Path(report_path).exists():
                logger.error(f"Report file not found: {report_path}")
                return False
            
            with open(report_path, 'r') as f:
                report_content = f.read()
            
            # Prepare update payload
            update_data = {
                "state": self._get_state_code(state),
                "work_notes": work_notes or f"Cluster analysis report generated and attached",
                "description": f"Automated cluster analysis completed on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                "u_cluster_analysis_report": report_path  # Custom field - adjust as needed
            }
            
            url = f"{self.instance_url}/api/now/table/{self.table_name}/{incident_id}"
            
            logger.info(f"Updating incident: {incident_id}")
            
            response = requests.patch(
                url,
                json=update_data,
                auth=self.auth,
                headers=self.headers,
                timeout=30
            )
            response.raise_for_status()
            
            logger.info(f"✅ Incident updated: {incident_id}")
            
            # Attach report as file (if API supports it)
            self._attach_file_to_incident(incident_id, report_path)
            
            return True
            
        except Exception as e:
            logger.error(f"Error updating incident: {str(e)}")
            return False
    
    def create_incident(self, cluster_id: str, pod_name: str, namespace: str,
                       severity: str = "2") -> Optional[str]:
        """Create new incident for cluster issue"""
        
        if not self.enabled:
            logger.warning("ServiceNow not enabled")
            return None
        
        try:
            incident_data = {
                "short_description": f"Pod {pod_name} crash in {namespace} on {cluster_id}",
                "description": f"""
Pod Crash Incident
==================
Cluster: {cluster_id}
Pod: {pod_name}
Namespace: {namespace}
Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Automated Kubernetes cluster analysis initiated.
Waiting for analysis results...
                """,
                "urgency": severity,
                "impact": "2",
                "assignment_group": os.getenv("SERVICENOW_ASSIGN_GROUP", "Kubernetes Team"),
                "category": "Software",
                "subcategory": "Application Crash",
                "cmdb_ci": f"cluster-{cluster_id}"
            }
            
            url = f"{self.instance_url}/api/now/table/{self.table_name}"
            
            logger.info("Creating new incident...")
            
            response = requests.post(
                url,
                json=incident_data,
                auth=self.auth,
                headers=self.headers,
                timeout=30
            )
            response.raise_for_status()
            
            result = response.json().get('result', {})
            incident_id = result.get('sys_id')
            
            logger.info(f"✅ Incident created: {incident_id}")
            
            return incident_id
            
        except Exception as e:
            logger.error(f"Error creating incident: {str(e)}")
            return None
    
    def _attach_file_to_incident(self, incident_id: str, file_path: str) -> bool:
        """Attach file to incident"""
        
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                logger.warning(f"File not found: {file_path}")
                return False
            
            url = f"{self.instance_url}/api/now/attachment/file"
            
            with open(file_path, 'rb') as f:
                files = {'file': f}
                data = {
                    'table_name': self.table_name,
                    'table_sys_id': incident_id,
                    'file_name': file_path.name
                }
                
                response = requests.post(
                    url,
                    files=files,
                    data=data,
                    auth=self.auth,
                    timeout=30
                )
                response.raise_for_status()
            
            logger.info(f"✅ File attached: {file_path.name}")
            return True
            
        except Exception as e:
            logger.warning(f"Could not attach file: {str(e)}")
            return False
    
    def _get_state_code(self, state: str) -> str:
        """Convert state name to ServiceNow state code"""
        state_map = {
            "new": "1",
            "in_progress": "2",
            "on_hold": "3",
            "resolved": "6",
            "closed": "7"
        }
        return state_map.get(state.lower(), "2")
    
    def add_work_note(self, incident_id: str, note: str) -> bool:
        """Add work note to incident"""
        
        if not self.enabled:
            logger.warning("ServiceNow not enabled")
            return False
        
        try:
            update_data = {
                "work_notes": note
            }
            
            url = f"{self.instance_url}/api/now/table/{self.table_name}/{incident_id}"
            
            response = requests.patch(
                url,
                json=update_data,
                auth=self.auth,
                headers=self.headers,
                timeout=30
            )
            response.raise_for_status()
            
            logger.info("✅ Work note added")
            return True
            
        except Exception as e:
            logger.error(f"Error adding work note: {str(e)}")
            return False
    
    def search_incidents(self, query: str) -> list:
        """Search for incidents"""
        
        if not self.enabled:
            logger.warning("ServiceNow not enabled")
            return []
        
        try:
            url = f"{self.instance_url}/api/now/table/{self.table_name}"
            
            params = {
                "sysparm_query": query,
                "sysparm_limit": "10"
            }
            
            response = requests.get(
                url,
                params=params,
                auth=self.auth,
                headers=self.headers,
                timeout=30
            )
            response.raise_for_status()
            
            results = response.json().get('result', [])
            logger.info(f"✅ Found {len(results)} incidents")
            
            return results
            
        except Exception as e:
            logger.error(f"Error searching incidents: {str(e)}")
            return []

def test_servicenow_connection():
    """Test ServiceNow connection"""
    logger.info("Testing ServiceNow connection...")
    
    client = ServiceNowClient()
    
    if not client.enabled:
        print("❌ ServiceNow credentials not configured")
        print("\nSet the following environment variables:")
        print("  SERVICENOW_INSTANCE_URL=https://your-instance.service-now.com")
        print("  SERVICENOW_USERNAME=your-username")
        print("  SERVICENOW_PASSWORD=your-password")
        print("  SERVICENOW_TABLE=incident")
        return
    
    try:
        # Test basic connection
        incidents = client.search_incidents("ORDERBYDESCsys_created_on^LIMIT1")
        if incidents:
            print(f"✅ ServiceNow connection successful")
            print(f"   Found {len(incidents)} recent incident(s)")
        else:
            print("⚠️  Connection successful but no incidents found")
    except Exception as e:
        print(f"❌ Connection test failed: {str(e)}")

if __name__ == "__main__":
    test_servicenow_connection()
