#!/usr/bin/env python3
"""
Generate Cluster Analysis Report using Claude AI
Analyzes diagnostic data and creates professional HTML report
"""

import os
import sys
import json
from pathlib import Path
from datetime import datetime
import logging
from typing import Dict, Any, Optional
from dotenv import load_dotenv
from jinja2 import Template
import anthropic

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

class ReportGenerator:
    def __init__(self, diagnostics_dir: str, cluster_id: str, namespace: str, pod_name: str):
        self.diagnostics_dir = Path(diagnostics_dir)
        self.cluster_id = cluster_id
        self.namespace = namespace
        self.pod_name = pod_name
        self.client = anthropic.Anthropic(api_key=os.getenv("CLAUDE_API_KEY"))
        self.analysis_result = None
        
    def read_file(self, filename: str) -> str:
        """Read diagnostic file, return content or placeholder"""
        filepath = self.diagnostics_dir / filename
        try:
            if filepath.exists():
                with open(filepath, 'r') as f:
                    return f.read()
        except Exception as e:
            logger.warning(f"Could not read {filename}: {str(e)}")
        return f"[File not found or unreadable: {filename}]"

    def prepare_analysis_prompt(self) -> str:
        """Prepare comprehensive prompt for Claude analysis"""
        
        pod_describe = self.read_file("pod-describe.json")[:2000]
        current_logs = self.read_file("pod-logs-current.log")[:2000]
        previous_logs = self.read_file("pod-logs-previous.log")[:2000]
        pod_events = self.read_file("pod-events.json")[:1500]
        node_describe = self.read_file("node-describe.json")[:1500]
        pod_resource = self.read_file("pods-resource-usage.txt")[:1000]
        prometheus_mem = self.read_file("prometheus-memory.json")[:500]
        prometheus_cpu = self.read_file("prometheus-cpu.json")[:500]
        openobserve = self.read_file("openobserve-errors.json")[:1500]
        
        prompt = f"""You are an expert Kubernetes DevOps engineer and production support specialist. 
Analyze the following comprehensive cluster diagnostics and provide a structured root cause analysis report.

CLUSTER INFORMATION:
- Cluster ID: {self.cluster_id}
- Namespace: {self.namespace}
- Pod Name: {self.pod_name}
- Analysis Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

DIAGNOSTIC DATA:

=== POD CONFIGURATION ===
{pod_describe}

=== CURRENT LOGS ===
{current_logs}

=== PREVIOUS CRASH LOGS (if available) ===
{previous_logs}

=== POD EVENTS ===
{pod_events}

=== NODE INFORMATION ===
{node_describe}

=== RESOURCE USAGE ===
{pod_resource}

=== PROMETHEUS METRICS ===
Memory: {prometheus_mem}
CPU: {prometheus_cpu}

=== OPENOBSERVE ERROR LOGS ===
{openobserve}

REQUIRED ANALYSIS OUTPUT:

Please provide a comprehensive analysis in the following structure:

1. **ROOT CAUSE ANALYSIS**
   - What is the primary issue causing the pod crash/failure?
   - What is the root cause (not just symptoms)?
   - Confidence level (High/Medium/Low)

2. **SEVERITY ASSESSMENT**
   - Critical / High / Medium / Low
   - Business impact assessment

3. **SYMPTOMS OBSERVED**
   - List all observable indicators and symptoms
   - Timeline of events if crash is recent
   - Error patterns identified

4. **AFFECTED COMPONENTS**
   - What services/pods/nodes are impacted?
   - Blast radius assessment
   - Dependencies affected

5. **IMMEDIATE ACTIONS (Do these NOW)**
   - Step-by-step actions to resolve immediately
   - Expected outcome for each action
   - Estimated time to resolution

6. **LONG-TERM RESOLUTION**
   - How to prevent this issue in the future
   - Configuration changes needed
   - Code/deployment updates required

7. **MONITORING RECOMMENDATIONS**
   - What alerts should be added?
   - Metrics to track going forward
   - Threshold recommendations
   - Log patterns to monitor

8. **RELATED ISSUES**
   - Are there similar issues in the cluster?
   - Known Kubernetes issues this might relate to?
   - Version compatibility issues?

9. **KNOWLEDGE BASE REFERENCES**
   - Link relevant Kubernetes documentation
   - Common causes and solutions
   - Best practices for this scenario

Please format the analysis clearly with headers and bullet points for easy reading and actionable guidance."""
        
        return prompt

    def analyze_with_claude(self) -> str:
        """Send diagnostics to Claude for analysis"""
        logger.info("🤖 Sending diagnostics to Claude for analysis...")
        
        prompt = self.prepare_analysis_prompt()
        
        try:
            message = self.client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=2000,
                messages=[
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )
            
            analysis = message.content[0].text
            self.analysis_result = analysis
            logger.info("✅ Claude analysis complete")
            return analysis
            
        except Exception as e:
            logger.error(f"Error calling Claude API: {str(e)}")
            raise

    def format_analysis_to_html(self, analysis: str) -> str:
        """Convert Claude's analysis into structured HTML"""
        
        # Extract severity from analysis
        severity = "Medium"
        severity_map = {
            "critical": ("Critical", "critical"),
            "high": ("High", "high"),
            "medium": ("Medium", "medium"),
            "low": ("Low", "low")
        }
        
        for keyword, (level, css_class) in severity_map.items():
            if keyword.lower() in analysis.lower():
                severity = level
                break
        
        # Parse sections from analysis
        sections_html = self._parse_analysis_sections(analysis)
        
        return sections_html, severity

    def _parse_analysis_sections(self, analysis: str) -> str:
        """Parse Claude's analysis into HTML sections"""
        
        html = ""
        current_section = None
        section_content = []
        
        for line in analysis.split('\n'):
            line = line.strip()
            
            # Check for section headers
            if line.startswith(('1.', '2.', '3.', '4.', '5.', '6.', '7.', '8.', '9.')):
                # Save previous section
                if current_section:
                    html += self._format_section(current_section, '\n'.join(section_content))
                
                # Start new section
                current_section = line
                section_content = []
            elif current_section:
                section_content.append(line)
        
        # Save last section
        if current_section:
            html += self._format_section(current_section, '\n'.join(section_content))
        
        return html

    def _format_section(self, title: str, content: str) -> str:
        """Format a single analysis section as HTML"""
        
        # Extract title without numbering
        title_clean = title.split('.', 1)[1].strip() if '.' in title else title
        title_clean = title_clean.replace('**', '').strip()
        
        # Format content
        lines = [l.strip() for l in content.split('\n') if l.strip()]
        formatted_lines = []
        
        for line in lines:
            if line.startswith('-'):
                formatted_lines.append(f"<li>{line[1:].strip()}</li>")
            elif line:
                formatted_lines.append(f"<p>{line}</p>")
        
        content_html = ""
        if any(l.startswith('<li>') for l in formatted_lines):
            # Wrap list items
            ul_content = ''.join([l for l in formatted_lines if l.startswith('<li>')])
            p_content = ''.join([l for l in formatted_lines if l.startswith('<p>')])
            content_html = p_content + f"<ul>{ul_content}</ul>"
        else:
            content_html = ''.join(formatted_lines)
        
        return f"""
        <div class="analysis-section">
            <h2>{title_clean}</h2>
            {content_html}
        </div>
        """

    def generate_html_report(self, analysis: str) -> str:
        """Generate complete HTML report"""
        logger.info("📝 Generating HTML report...")
        
        sections_html, severity = self.format_analysis_to_html(analysis)
        
        html_template = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cluster Analysis Report - {{ pod_name }}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 32px;
            margin-bottom: 10px;
        }
        
        .header p {
            font-size: 14px;
            opacity: 0.9;
        }
        
        .metadata {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            padding: 30px;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }
        
        @media (max-width: 768px) {
            .metadata {
                grid-template-columns: 1fr;
            }
        }
        
        .metadata-item {
            display: flex;
            flex-direction: column;
        }
        
        .metadata-item label {
            font-weight: 600;
            color: #667eea;
            font-size: 12px;
            text-transform: uppercase;
            margin-bottom: 5px;
        }
        
        .metadata-item value {
            font-size: 16px;
            color: #333;
            font-family: monospace;
            word-break: break-all;
        }
        
        .content {
            padding: 40px;
        }
        
        .analysis-section {
            margin-bottom: 30px;
            page-break-inside: avoid;
        }
        
        .analysis-section h2 {
            color: #667eea;
            font-size: 22px;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 3px solid #667eea;
        }
        
        .analysis-section p {
            line-height: 1.8;
            color: #555;
            margin-bottom: 12px;
        }
        
        .analysis-section ul {
            margin-left: 30px;
            color: #555;
            line-height: 1.8;
            margin-bottom: 15px;
        }
        
        .analysis-section li {
            margin-bottom: 8px;
            list-style-type: disc;
        }
        
        .severity-badge {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 600;
            font-size: 16px;
            margin-bottom: 30px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .severity-badge.critical {
            background: #dc3545;
            color: white;
        }
        
        .severity-badge.high {
            background: #fd7e14;
            color: white;
        }
        
        .severity-badge.medium {
            background: #ffc107;
            color: black;
        }
        
        .severity-badge.low {
            background: #28a745;
            color: white;
        }
        
        .code-block {
            background: #f8f9fa;
            border-left: 4px solid #667eea;
            padding: 15px;
            margin: 15px 0;
            font-family: 'Courier New', monospace;
            font-size: 13px;
            overflow-x: auto;
            border-radius: 4px;
            line-height: 1.5;
        }
        
        .footer {
            background: #f8f9fa;
            padding: 30px 40px;
            text-align: center;
            font-size: 12px;
            color: #888;
            border-top: 1px solid #e9ecef;
        }
        
        .footer p {
            margin-bottom: 10px;
        }
        
        .quick-actions {
            background: linear-gradient(135deg, #e7f3ff 0%, #f0f8ff 100%);
            border-left: 4px solid #667eea;
            padding: 20px;
            margin: 20px 0;
            border-radius: 4px;
        }
        
        .quick-actions h3 {
            color: #667eea;
            margin-bottom: 10px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
        }
        
        th {
            background: #667eea;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }
        
        td {
            padding: 12px;
            border-bottom: 1px solid #e9ecef;
        }
        
        tr:nth-child(even) {
            background: #f8f9fa;
        }
        
        @media print {
            body {
                background: white;
            }
            .container {
                box-shadow: none;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔍 Kubernetes Cluster Analysis Report</h1>
            <p>Automated Pod Crash & Performance Diagnostics</p>
        </div>
        
        <div class="metadata">
            <div class="metadata-item">
                <label>Cluster ID</label>
                <value>{{ cluster_id }}</value>
            </div>
            <div class="metadata-item">
                <label>Pod Name</label>
                <value>{{ pod_name }}</value>
            </div>
            <div class="metadata-item">
                <label>Namespace</label>
                <value>{{ namespace }}</value>
            </div>
            <div class="metadata-item">
                <label>Analysis Timestamp</label>
                <value>{{ timestamp }}</value>
            </div>
        </div>
        
        <div class="content">
            <div class="severity-badge {{ severity_class }}">
                Severity: {{ severity }}
            </div>
            
            {{ sections_html | safe }}
            
            <div class="quick-actions">
                <h3>📋 Next Steps</h3>
                <ol style="margin-left: 20px; color: #333; line-height: 1.8;">
                    <li>Review the Root Cause Analysis section above</li>
                    <li>Execute the recommended "Immediate Actions" in priority order</li>
                    <li>Monitor the pod and metrics after remediation</li>
                    <li>Implement the "Long-term Resolution" recommendations</li>
                    <li>Add suggested monitoring alerts from the "Monitoring Recommendations" section</li>
                    <li>Update your incident ticket (ServiceNow/Jira) with findings</li>
                    <li>Schedule post-incident review with the team</li>
                </ol>
            </div>
        </div>
        
        <div class="footer">
            <p><strong>Generated by Claude AI Analysis Engine</strong></p>
            <p>Powered by Anthropic's Claude API</p>
            <p>Report ID: {{ cluster_id }}-{{ pod_name }}-{{ report_id }}</p>
            <p style="margin-top: 15px; color: #aaa;">For questions or issues with this analysis, contact your DevOps team.</p>
        </div>
    </div>
</body>
</html>"""
        
        template = Template(html_template)
        
        severity_class = severity.lower()
        report_id = datetime.now().strftime("%Y%m%d%H%M%S")
        
        html_content = template.render(
            cluster_id=self.cluster_id,
            pod_name=self.pod_name,
            namespace=self.namespace,
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            severity=severity,
            severity_class=severity_class,
            sections_html=sections_html,
            report_id=report_id
        )
        
        return html_content

    def save_report(self, html_content: str) -> str:
        """Save HTML report to file"""
        report_path = self.diagnostics_dir / "analysis-report.html"
        
        try:
            with open(report_path, 'w') as f:
                f.write(html_content)
            logger.info(f"✅ Report saved: {report_path}")
            return str(report_path)
        except Exception as e:
            logger.error(f"Error saving report: {str(e)}")
            raise

    def run(self) -> str:
        """Run complete report generation"""
        logger.info("📊 Starting report generation...")
        
        # Get Claude analysis
        analysis = self.analyze_with_claude()
        
        # Generate HTML
        html_content = self.generate_html_report(analysis)
        
        # Save report
        report_path = self.save_report(html_content)
        
        logger.info(f"✅ Report generation complete: {report_path}")
        return report_path

def main():
    if len(sys.argv) < 5:
        print("Usage: python generate_report.py <diagnostics_dir> <cluster_id> <namespace> <pod_name>")
        print("\nExample:")
        print("  python generate_report.py cluster-reports/prod-cluster-1/20240115_143022 prod-cluster-1 payment-service my-pod-xyz")
        sys.exit(1)
    
    diagnostics_dir = sys.argv[1]
    cluster_id = sys.argv[2]
    namespace = sys.argv[3]
    pod_name = sys.argv[4]
    
    generator = ReportGenerator(diagnostics_dir, cluster_id, namespace, pod_name)
    report_path = generator.run()
    
    print(f"\n✅ Report generated: {report_path}")
    sys.exit(0)

if __name__ == "__main__":
    main()
