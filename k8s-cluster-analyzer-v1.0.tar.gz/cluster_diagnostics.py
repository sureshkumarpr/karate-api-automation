#!/usr/bin/env python3
"""
Cluster Diagnostics Collector
Collects comprehensive diagnostic data from Kubernetes clusters on AKS
"""

import os
import sys
import json
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List
import logging
from dotenv import load_dotenv

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

class ClusterDiagnostics:
    def __init__(self, cluster_id: str, namespace: str, pod_name: str):
        self.cluster_id = cluster_id
        self.namespace = namespace
        self.pod_name = pod_name
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.report_dir = Path(f"cluster-reports/{cluster_id}/{self.timestamp}")
        self.report_dir.mkdir(parents=True, exist_ok=True)
        self.diagnostics = {}
        
    def run_kubectl_command(self, command: List[str], description: str = "") -> str:
        """Execute kubectl command and return output"""
        try:
            logger.info(f"Executing: {' '.join(command)}")
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode != 0:
                logger.warning(f"Command failed: {result.stderr}")
                return f"Error: {result.stderr}"
            return result.stdout
        except subprocess.TimeoutExpired:
            logger.error("Command timed out")
            return "Error: Command timed out"
        except Exception as e:
            logger.error(f"Error executing command: {str(e)}")
            return f"Error: {str(e)}"

    def run_az_command(self, command: List[str]) -> str:
        """Execute Azure CLI command"""
        try:
            logger.info(f"Executing Azure CLI: {' '.join(command)}")
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode != 0:
                logger.warning(f"Azure CLI command failed: {result.stderr}")
                return f"Error: {result.stderr}"
            return result.stdout
        except Exception as e:
            logger.error(f"Error executing Azure command: {str(e)}")
            return f"Error: {str(e)}"

    def setup_cluster_connection(self):
        """Connect to AKS cluster"""
        logger.info(f"Connecting to cluster: {self.cluster_id}")
        
        subscription_id = os.getenv("AZURE_SUBSCRIPTION_ID")
        resource_group = os.getenv("AZURE_RESOURCE_GROUP", self.cluster_id)
        
        # Set subscription
        self.run_az_command([
            "az", "account", "set",
            "--subscription", subscription_id
        ])
        
        # Get cluster credentials
        self.run_az_command([
            "az", "aks", "get-credentials",
            "--resource-group", resource_group,
            "--name", self.cluster_id,
            "--overwrite-existing"
        ])
        
        logger.info("✅ Connected to cluster")

    def collect_pod_diagnostics(self):
        """Collect pod-specific diagnostics"""
        logger.info("📊 Collecting pod diagnostics...")
        
        # Pod describe
        pod_describe = self.run_kubectl_command(
            ["kubectl", "describe", "pod", self.pod_name, "-n", self.namespace, "-o", "json"]
        )
        self.save_file("pod-describe.json", pod_describe)
        
        # Current logs
        current_logs = self.run_kubectl_command(
            ["kubectl", "logs", self.pod_name, "-n", self.namespace, "--tail=500"]
        )
        self.save_file("pod-logs-current.log", current_logs)
        
        # Previous logs (if crashed)
        previous_logs = self.run_kubectl_command(
            ["kubectl", "logs", self.pod_name, "-n", self.namespace, "--previous", "--tail=500"]
        )
        self.save_file("pod-logs-previous.log", previous_logs)
        
        # Pod events
        pod_events = self.run_kubectl_command(
            ["kubectl", "get", "events", "-n", self.namespace, 
             "--field-selector", f"involvedObject.name={self.pod_name}", "-o", "json"]
        )
        self.save_file("pod-events.json", pod_events)
        
        logger.info("✅ Pod diagnostics collected")

    def collect_node_diagnostics(self):
        """Collect node diagnostics"""
        logger.info("📊 Collecting node diagnostics...")
        
        # Get node name
        pod_describe = self.run_kubectl_command(
            ["kubectl", "get", "pod", self.pod_name, "-n", self.namespace, 
             "-o", "jsonpath={.spec.nodeName}"]
        )
        node_name = pod_describe.strip()
        
        if not node_name:
            logger.warning("Could not determine node name")
            return
        
        self.diagnostics['node_name'] = node_name
        
        # Node describe
        node_describe = self.run_kubectl_command(
            ["kubectl", "describe", "node", node_name, "-o", "json"]
        )
        self.save_file("node-describe.json", node_describe)
        
        # Node resource usage
        node_top = self.run_kubectl_command(
            ["kubectl", "top", "node", node_name]
        )
        self.save_file("node-top.txt", node_top)
        
        logger.info("✅ Node diagnostics collected")

    def collect_cluster_metrics(self):
        """Collect cluster-wide metrics"""
        logger.info("📊 Collecting cluster metrics...")
        
        # Pods in namespace
        pods_ns = self.run_kubectl_command(
            ["kubectl", "get", "pods", "-n", self.namespace, "-o", "wide"]
        )
        self.save_file("pods-namespace.txt", pods_ns)
        
        # Pod resource usage
        pods_resource = self.run_kubectl_command(
            ["kubectl", "top", "pods", "-n", self.namespace]
        )
        self.save_file("pods-resource-usage.txt", pods_resource)
        
        # Node status
        nodes_status = self.run_kubectl_command(
            ["kubectl", "get", "nodes", "-o", "wide"]
        )
        self.save_file("nodes-status.txt", nodes_status)
        
        # Workloads
        workloads = self.run_kubectl_command(
            ["kubectl", "get", "deployment,replicaset,statefulset", "-n", self.namespace, "-o", "wide"]
        )
        self.save_file("workloads.txt", workloads)
        
        logger.info("✅ Cluster metrics collected")

    def collect_prometheus_metrics(self):
        """Collect Prometheus metrics"""
        logger.info("📊 Collecting Prometheus metrics...")
        
        prometheus_url = os.getenv("PROMETHEUS_URL", "http://prometheus:9090")
        
        try:
            import requests
            
            # Memory metrics
            memory_query = f'container_memory_usage_bytes{{pod_name="{self.pod_name}"}}'
            memory_response = requests.get(
                f"{prometheus_url}/api/v1/query",
                params={"query": memory_query},
                timeout=10
            )
            self.save_file("prometheus-memory.json", json.dumps(memory_response.json(), indent=2))
            
            # CPU metrics
            cpu_query = f'rate(container_cpu_usage_seconds_total{{pod_name="{self.pod_name}"}}[5m])'
            cpu_response = requests.get(
                f"{prometheus_url}/api/v1/query",
                params={"query": cpu_query},
                timeout=10
            )
            self.save_file("prometheus-cpu.json", json.dumps(cpu_response.json(), indent=2))
            
            # Network metrics
            network_query = f'rate(container_network_receive_bytes_total{{pod_name="{self.pod_name}"}}[5m])'
            network_response = requests.get(
                f"{prometheus_url}/api/v1/query",
                params={"query": network_query},
                timeout=10
            )
            self.save_file("prometheus-network.json", json.dumps(network_response.json(), indent=2))
            
            logger.info("✅ Prometheus metrics collected")
        except Exception as e:
            logger.warning(f"Could not collect Prometheus metrics: {str(e)}")

    def collect_openobserve_logs(self):
        """Collect logs from OpenObserve"""
        logger.info("📊 Collecting OpenObserve logs...")
        
        try:
            import requests
            
            openobserve_url = os.getenv("OPENOBSERVE_URL")
            openobserve_token = os.getenv("OPENOBSERVE_TOKEN")
            
            if not openobserve_url or not openobserve_token:
                logger.warning("OpenObserve credentials not configured")
                return
            
            headers = {
                "Authorization": f"Bearer {openobserve_token}",
                "Content-Type": "application/json"
            }
            
            # Query for errors
            query_payload = {
                "query": f'pod_name:{self.pod_name} AND level:ERROR',
                "start_time": int((datetime.now().timestamp() - 3600) * 1000000),
                "end_time": int(datetime.now().timestamp() * 1000000),
                "limit": 100
            }
            
            response = requests.post(
                f"{openobserve_url}/api/v1/search",
                json=query_payload,
                headers=headers,
                timeout=30
            )
            
            self.save_file("openobserve-errors.json", json.dumps(response.json(), indent=2))
            logger.info("✅ OpenObserve logs collected")
        except Exception as e:
            logger.warning(f"Could not collect OpenObserve logs: {str(e)}")

    def save_file(self, filename: str, content: str):
        """Save content to file"""
        filepath = self.report_dir / filename
        try:
            with open(filepath, 'w') as f:
                f.write(content)
            logger.debug(f"Saved: {filename}")
        except Exception as e:
            logger.error(f"Error saving file {filename}: {str(e)}")

    def generate_summary(self):
        """Generate diagnostics summary"""
        summary = f"""CLUSTER ANALYSIS SUMMARY
========================
Cluster ID: {self.cluster_id}
Namespace: {self.namespace}
Pod Name: {self.pod_name}
Analysis Time: {self.timestamp}
Node: {self.diagnostics.get('node_name', 'Unknown')}

Collected Data:
- pod-describe.json (Pod configuration and status)
- pod-logs-current.log (Current logs)
- pod-logs-previous.log (Previous crash logs)
- pod-events.json (Pod events)
- node-describe.json (Node details)
- node-top.txt (Node resource usage)
- pods-namespace.txt (All pods in namespace)
- pods-resource-usage.txt (Pod resource metrics)
- nodes-status.txt (Cluster node status)
- workloads.txt (Deployments, ReplicaSets, StatefulSets)
- openobserve-errors.json (Error logs from OpenObserve)
- prometheus-*.json (Prometheus metrics)

Next: Send to Claude API for analysis
"""
        self.save_file("summary.txt", summary)
        logger.info("✅ Summary generated")

    def run(self) -> str:
        """Run complete diagnostic collection"""
        logger.info("🚀 Starting cluster diagnostics collection...")
        logger.info(f"Report directory: {self.report_dir}")
        
        try:
            self.setup_cluster_connection()
            self.collect_pod_diagnostics()
            self.collect_node_diagnostics()
            self.collect_cluster_metrics()
            self.collect_prometheus_metrics()
            self.collect_openobserve_logs()
            self.generate_summary()
            
            logger.info(f"✅ Diagnostics collection complete: {self.report_dir}")
            return str(self.report_dir)
        except Exception as e:
            logger.error(f"Fatal error during diagnostics collection: {str(e)}")
            raise

def main():
    if len(sys.argv) < 4:
        print("Usage: python cluster_diagnostics.py <cluster_id> <namespace> <pod_name>")
        print("\nExample:")
        print("  python cluster_diagnostics.py prod-cluster-1 payment-service my-pod-xyz")
        sys.exit(1)
    
    cluster_id = sys.argv[1]
    namespace = sys.argv[2]
    pod_name = sys.argv[3]
    
    diagnostics = ClusterDiagnostics(cluster_id, namespace, pod_name)
    report_dir = diagnostics.run()
    
    print(f"\n✅ Diagnostics saved to: {report_dir}")
    sys.exit(0)

if __name__ == "__main__":
    main()
