# GitHub Setup & Deployment Guide

Complete guide to push the Kubernetes Cluster Analysis Tool to GitHub and set up for collaboration.

## Table of Contents

1. [Create GitHub Repository](#create-github-repository)
2. [Initialize Local Git Repository](#initialize-local-git-repository)
3. [Push to GitHub](#push-to-github)
4. [GitHub Configuration](#github-configuration)
5. [GitHub Actions Setup](#github-actions-setup)
6. [Collaboration Setup](#collaboration-setup)

---

## Create GitHub Repository

### Step 1: Create Repository on GitHub.com

1. Go to https://github.com/new
2. Fill in repository details:
   - **Repository name**: `k8s-cluster-analyzer`
   - **Description**: `Kubernetes Cluster Analysis Tool - Powered by Claude AI`
   - **Visibility**: Public (or Private if preferred)
   - **Initialize with**: Leave unchecked (we'll push existing code)

3. Click **"Create repository"**

### Step 2: Note Your Repository URL

Copy the repository URL from GitHub:
```
https://github.com/yourusername/k8s-cluster-analyzer.git
```

Or using SSH:
```
git@github.com:yourusername/k8s-cluster-analyzer.git
```

---

## Initialize Local Git Repository

### Step 1: Navigate to Project Directory

```bash
cd path/to/k8s-cluster-analyzer
```

### Step 2: Initialize Git

```bash
# Initialize git repository
git init

# Verify initialization
git status
```

### Step 3: Configure Git User (First Time Only)

```bash
# Set your name
git config user.name "Sureshkumar Ramasamy"

# Set your email
git config user.email "sureshkumar.ramasamy@walmart.com"

# Verify configuration
git config --list
```

Or set globally:
```bash
git config --global user.name "Sureshkumar Ramasamy"
git config --global user.email "sureshkumar.ramasamy@walmart.com"
```

---

## Push to GitHub

### Step 1: Add Files to Git

```bash
# Add all files
git add .

# Or add specific files
git add README.md requirements.txt run_cluster_analysis.py

# Verify files to be committed
git status
```

### Step 2: Create Initial Commit

```bash
git commit -m "Initial commit: Kubernetes Cluster Analysis Tool

- Automated cluster diagnostics collection
- Claude AI-powered root cause analysis
- Professional HTML report generation
- ServiceNow integration
- Email notifications
- REST API endpoints"
```

### Step 3: Rename Default Branch to 'main'

```bash
# If on 'master' branch
git branch -M main
```

### Step 4: Add Remote Repository

```bash
# Add GitHub as remote
git remote add origin https://github.com/yourusername/k8s-cluster-analyzer.git

# Verify remote
git remote -v
```

### Step 5: Push to GitHub

```bash
# Push main branch
git push -u origin main

# Verify push
git branch -vv
```

### Common Push Issues & Solutions

**"Permission denied (publickey)"**
```bash
# Generate SSH key
ssh-keygen -t ed25519 -C "sureshkumar.ramasamy@walmart.com"

# Add key to ssh-agent
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519

# Add public key to GitHub:
# 1. Copy: cat ~/.ssh/id_ed25519.pub
# 2. Go to: https://github.com/settings/ssh/new
# 3. Paste the key
# 4. Save

# Test connection
ssh -T git@github.com
```

**"Incorrect username or password"**
```bash
# Use personal access token instead of password
# Create token at: https://github.com/settings/tokens

# When prompted for password, paste the token
git push -u origin main
```

---

## GitHub Configuration

### Step 1: Add Repository Description

1. Go to repository settings: https://github.com/yourusername/k8s-cluster-analyzer/settings
2. Scroll to "Repository description"
3. Add:
   ```
   End-to-end Kubernetes cluster analysis with Claude AI. 
   Automated diagnostics collection, intelligent analysis, and professional reports.
   ```

### Step 2: Add Topics

1. In repository home page, click the gear icon next to "About"
2. Add topics:
   - `kubernetes`
   - `devops`
   - `incident-response`
   - `ai`
   - `claude`
   - `troubleshooting`
   - `python`

### Step 3: Enable Features

1. Go to Settings → Features
2. Enable:
   - ✅ Issues
   - ✅ Discussions
   - ✅ Wiki (optional)
   - ✅ Sponsorships (optional)

### Step 4: Add Code Owners (Optional)

Create `.github/CODEOWNERS`:

```
# Default owner for everything
* @sureshkumar-ramasamy

# Python files
*.py @sureshkumar-ramasamy

# Documentation
*.md @sureshkumar-ramasamy
```

Commit and push:
```bash
git add .github/CODEOWNERS
git commit -m "Add CODEOWNERS file"
git push
```

---

## GitHub Actions Setup

### Step 1: Create CI/CD Workflow

Create `.github/workflows/ci.yml`:

```yaml
name: CI/CD Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      
      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install flake8 black isort
      
      - name: Lint with flake8
        run: flake8 . --count --select=E9,F63,F7,F82 --show-source --statistics
      
      - name: Format check with black
        run: black --check .

  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ['3.8', '3.9', '3.10', '3.11']
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Python ${{ matrix.python-version }}
        uses: actions/setup-python@v4
        with:
          python-version: ${{ matrix.python-version }}
      
      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install -r requirements.txt pytest pytest-cov
      
      - name: Run tests
        run: pytest --cov=. --cov-report=xml
      
      - name: Upload coverage
        uses: codecov/codecov-action@v3

  security:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      
      - name: Install dependencies
        run: |
          pip install bandit safety
      
      - name: Run Bandit security check
        run: bandit -r . -f json -o bandit-report.json || true
      
      - name: Check dependencies for vulnerabilities
        run: safety check || true

  build:
    needs: [lint, test, security]
    runs-on: ubuntu-latest
    if: github.event_name == 'push'
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v2
      
      - name: Build Docker image
        uses: docker/build-push-action@v4
        with:
          context: .
          push: false
          tags: ${{ github.repository }}:latest
```

Commit and push:
```bash
git add .github/workflows/ci.yml
git commit -m "Add CI/CD pipeline"
git push
```

### Step 2: Create Release Workflow

Create `.github/workflows/release.yml`:

```yaml
name: Release

on:
  push:
    tags:
      - 'v*'

jobs:
  release:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Create Release Notes
        run: |
          echo "## Release ${{ github.ref }}" > RELEASE_NOTES.md
          echo "Version: $(echo ${{ github.ref }} | sed 's/refs\/tags\///')" >> RELEASE_NOTES.md
      
      - name: Create GitHub Release
        uses: softprops/action-gh-release@v1
        with:
          body_path: RELEASE_NOTES.md
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

---

## Collaboration Setup

### Step 1: Add Team Members

1. Go to Settings → Collaborators and teams
2. Click "Add people"
3. Enter GitHub usernames
4. Assign roles:
   - **Maintain**: Can manage repo without access to sensitive actions
   - **Triage**: Can manage issues and pull requests
   - **Write**: Can push to repo
   - **Read**: Read-only access

### Step 2: Create Branch Protection Rules

1. Go to Settings → Branches
2. Click "Add rule"
3. Configure:
   - Branch name pattern: `main`
   - ✅ Require pull request reviews before merging
   - ✅ Require status checks to pass before merging
   - ✅ Require branches to be up to date before merging
   - ✅ Require code reviews before merging
   - ✅ Require approval of the most recent reviewable push

### Step 3: Add Contributing Guidelines

Create `CONTRIBUTING.md`:

```markdown
# Contributing to Kubernetes Cluster Analysis Tool

## Getting Started

1. Fork the repository
2. Clone your fork: `git clone https://github.com/yourusername/k8s-cluster-analyzer.git`
3. Create feature branch: `git checkout -b feature/amazing-feature`
4. Make changes
5. Commit: `git commit -m 'Add amazing feature'`
6. Push: `git push origin feature/amazing-feature`
7. Create Pull Request

## Code Style

- Follow PEP 8
- Use Black for formatting
- Use isort for imports
- Add type hints
- Write docstrings

## Testing

- Write tests for new features
- Run: `pytest`
- Ensure 80%+ coverage

## Pull Request Process

1. Update README if needed
2. Add tests for new functionality
3. Ensure all tests pass
4. Request review from maintainers
5. Address feedback

## Questions?

- Open an issue
- Join discussions
- Contact maintainers
```

Commit and push:
```bash
git add CONTRIBUTING.md
git commit -m "Add contributing guidelines"
git push
```

### Step 4: Set Up Issue Templates

Create `.github/ISSUE_TEMPLATE/bug_report.md`:

```markdown
---
name: Bug Report
about: Report a bug
title: '[BUG] '
labels: 'bug'
assignees: ''
---

## Description
Brief description of the bug.

## Steps to Reproduce
1. Step 1
2. Step 2
3. ...

## Expected Behavior
What should happen?

## Actual Behavior
What actually happens?

## Environment
- OS: [e.g., Ubuntu 20.04]
- Python version: [e.g., 3.11]
- Tool version: [e.g., 1.0.0]

## Logs
```
Paste relevant logs here
```

## Additional Context
Any other context?
```

Create `.github/ISSUE_TEMPLATE/feature_request.md`:

```markdown
---
name: Feature Request
about: Suggest an idea
title: '[FEATURE] '
labels: 'enhancement'
assignees: ''
---

## Is your feature request related to a problem?
Description of the problem.

## Proposed Solution
How should this feature work?

## Alternative Solutions
Any alternatives you've considered?

## Additional Context
Any other context?
```

---

## Continuous Deployment

### Step 1: Create Deployment Workflow

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Deploy to production
        env:
          DEPLOY_KEY: ${{ secrets.DEPLOY_KEY }}
          DEPLOY_HOST: ${{ secrets.DEPLOY_HOST }}
        run: |
          mkdir -p ~/.ssh
          echo "$DEPLOY_KEY" > ~/.ssh/deploy_key
          chmod 600 ~/.ssh/deploy_key
          ssh -i ~/.ssh/deploy_key -o StrictHostKeyChecking=no user@$DEPLOY_HOST 'cd /app && git pull origin main && pip install -r requirements.txt'
```

### Step 2: Add Secrets

1. Go to Settings → Secrets and variables → Actions
2. Click "New repository secret"
3. Add:
   - `DEPLOY_KEY`: SSH private key for deployment
   - `DEPLOY_HOST`: Deployment server hostname
   - `CLAUDE_API_KEY`: Your Claude API key (if needed for CI)

---

## Monitoring & Analytics

### Step 1: Enable GitHub Insights

1. Go to repository Insights tab
2. View:
   - Contributions
   - Traffic
   - Network
   - Forks

### Step 2: Add Badges to README

Add to README.md:

```markdown
![GitHub Stars](https://img.shields.io/github/stars/yourusername/k8s-cluster-analyzer)
![GitHub Forks](https://img.shields.io/github/forks/yourusername/k8s-cluster-analyzer)
![GitHub Issues](https://img.shields.io/github/issues/yourusername/k8s-cluster-analyzer)
![GitHub License](https://img.shields.io/github/license/yourusername/k8s-cluster-analyzer)
![Python Version](https://img.shields.io/badge/Python-3.8%2B-blue)
```

---

## Next Steps

1. ✅ Repository created on GitHub
2. ✅ Code pushed to main branch
3. ✅ GitHub Actions configured
4. ✅ Branch protection enabled
5. ⏭️ Invite team members
6. ⏭️ Publish releases
7. ⏭️ Share with community

---

## Quick Reference

```bash
# Clone repository
git clone https://github.com/yourusername/k8s-cluster-analyzer.git

# Create feature branch
git checkout -b feature/my-feature

# Make changes and commit
git add .
git commit -m "Add my feature"

# Push to GitHub
git push origin feature/my-feature

# Create Pull Request on GitHub web interface

# After PR is merged, delete branch
git checkout main
git pull origin main
git branch -d feature/my-feature
```

## Support

For GitHub-specific questions:
- [GitHub Docs](https://docs.github.com/)
- [GitHub Community](https://github.community/)
- [GitHub Support](https://support.github.com/)

---

**Ready to deploy! 🚀**
