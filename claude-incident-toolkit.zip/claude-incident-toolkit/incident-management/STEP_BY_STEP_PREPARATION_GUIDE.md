# STEP-BY-STEP PREPARATION GUIDE
## Using Claude Prompts with Wibey CLI for Incident Management

**Target Audience**: DevOps Engineers, Production Support Executives at TCS  
**Duration**: 20 minutes to get fully set up  
**Outcome**: You'll be able to troubleshoot incidents 3x faster using Claude + Wibey

---

## TABLE OF CONTENTS

1. [Pre-Setup Checklist](#pre-setup)
2. [Phase 1: Environment Setup (5 minutes)](#phase-1)
3. [Phase 2: Template Organization (5 minutes)](#phase-2)
4. [Phase 3: Wibey CLI Configuration (5 minutes)](#phase-3)
5. [Phase 4: Test Run & Validation (5 minutes)](#phase-4)
6. [Phase 5: Team Integration (Optional)](#phase-5)
7. [Troubleshooting Common Issues](#troubleshooting)

---

## PRE-SETUP CHECKLIST {#pre-setup}

Before you start, make sure you have:

- [ ] Access to Wibey CLI (already have it)
- [ ] All 7 template files downloaded
- [ ] Access to your AKS cluster (kubectl configured)
- [ ] Prometheus/Grafana access (for monitoring templates)
- [ ] A text editor (VS Code, Notepad++, or similar)
- [ ] A real incident to test with (or staging environment)
- [ ] 20 minutes of uninterrupted time
- [ ] Internet connection for Claude API calls

**✓ If all checked, proceed to Phase 1**

---

## PHASE 1: ENVIRONMENT SETUP {#phase-1}

### Step 1.1: Create a Working Directory

**Linux/Mac:**
```bash
mkdir -p ~/claude-incident-templates
cd ~/claude-incident-templates
```

**Windows (PowerShell):**
```powershell
mkdir $env:USERPROFILE\Documents\claude-incident-templates
cd $env:USERPROFILE\Documents\claude-incident-templates
```

### Step 1.2: Verify Wibey CLI is Installed

```bash
# Test Wibey CLI connection
wibey --version

# Expected output:
# Wibey CLI version X.X.X
# Connected to: Anthropic Claude Models
```

**If not installed:**
- Contact your TCS administrator
- Wibey needs Anthropic API access
- Verify you have permissions for Haiku, Sonnet, and Opus models

### Step 1.3: Test Wibey Connection

```bash
# Quick test
wibey chat --model haiku "Say hello"

# Expected response:
# Hello! How can I help you today?
```

**If this works**, proceed to Phase 2.

---

## PHASE 2: TEMPLATE ORGANIZATION {#phase-2}

### Step 2.1: Save All Template Files

You should have these 9 files:

```
claude-incident-templates/
├── INCIDENT_PROMPT_TEMPLATES_GUIDE.md
├── QUICK_REFERENCE_CARD.txt
├── TEMPLATE_1_K8S_POD_CRASH.txt
├── TEMPLATE_2_AKS_CLUSTER.txt
├── TEMPLATE_3_PROMETHEUS_GRAFANA.txt
├── TEMPLATE_4_DEPLOYMENT_RELEASE.txt
├── TEMPLATE_5_NETWORK_CONNECTIVITY.txt
├── TEMPLATE_6_RESOURCE_CONSTRAINTS.txt
└── TEMPLATE_7_LOG_ANALYSIS.txt
```

**How to organize (create subdirectories):**

```bash
# Create by incident type
mkdir -p ~/claude-incident-templates/{kubernetes,azure,monitoring,deployment,network,resources,logs}

# Or create by priority
mkdir -p ~/claude-incident-templates/{critical,high,medium,low}

# Recommended: create both
mkdir -p ~/claude-incident-templates/{kubernetes,azure,monitoring,deployment,network,resources,logs}
mkdir -p ~/claude-incident-templates/resolved-incidents
```

### Step 2.2: Add Templates to Appropriate Folders

```bash
# Example organization
mv TEMPLATE_1_K8S_POD_CRASH.txt kubernetes/
mv TEMPLATE_2_AKS_CLUSTER.txt azure/
mv TEMPLATE_3_PROMETHEUS_GRAFANA.txt monitoring/
mv TEMPLATE_4_DEPLOYMENT_RELEASE.txt deployment/
mv TEMPLATE_5_NETWORK_CONNECTIVITY.txt network/
mv TEMPLATE_6_RESOURCE_CONSTRAINTS.txt resources/
mv TEMPLATE_7_LOG_ANALYSIS.txt logs/

# Keep reference cards in root
# QUICK_REFERENCE_CARD.txt → root
# INCIDENT_PROMPT_TEMPLATES_GUIDE.md → root
```

### Step 2.3: Create a Customization File

Create file: `MY_CUSTOMIZATIONS.txt`

```
# Add YOUR specific values here (use in all templates):

CLUSTER_NAME = [your-cluster-name]
REGION = [your-region]
NAMESPACE_PROD = [your-prod-namespace]
NAMESPACE_STAGING = [your-staging-namespace]
ACR_NAME = [your-acr-name]
PROMETHEUS_URL = [your-prometheus-url]
GRAFANA_URL = [your-grafana-url]
ALERT_MANAGER_URL = [your-alertmanager-url]
MY_TEAM_EMAIL = [team-email]
MY_SLACK_CHANNEL = [#incident-alerts or similar]
TCS_TOOLS = [ServiceNow, Jira, etc.]
```

**Purpose**: Quick reference to replace placeholder values.

---

## PHASE 3: WIBEY CLI CONFIGURATION {#phase-3}

### Step 3.1: Create Wibey Shortcuts (Aliases)

**For Linux/Mac - Add to `~/.bashrc` or `~/.zshrc`:**

```bash
# Claude Incident Analysis Shortcuts
alias claude-pod="wibey chat --model sonnet"
alias claude-cluster="wibey chat --model sonnet"
alias claude-monitor="wibey chat --model sonnet"
alias claude-deploy="wibey chat --model sonnet"
alias claude-network="wibey chat --model sonnet"
alias claude-resource="wibey chat --model sonnet"
alias claude-logs="wibey chat --model sonnet"
alias claude-quick="wibey chat --model haiku"

# Shortcut to templates directory
alias incidents="cd ~/claude-incident-templates"
```

**For Windows PowerShell - Create profile:**

```powershell
# Create profile if it doesn't exist
if (!(Test-Path -Path $PROFILE)) {
    New-Item -ItemType File -Path $PROFILE -Force
}

# Add to profile
$profile_content = @"
# Claude Incident Analysis Shortcuts
function claude-pod { wibey chat --model sonnet @args }
function claude-cluster { wibey chat --model sonnet @args }
function claude-monitor { wibey chat --model sonnet @args }
function claude-quick { wibey chat --model haiku @args }
function incidents { cd "$env:USERPROFILE\Documents\claude-incident-templates" }
"@

Add-Content -Path $PROFILE -Value $profile_content
. $PROFILE  # Reload profile
```

### Step 3.2: Create Helper Scripts

**Create file: `analyze_pod.sh` (Linux/Mac)**

```bash
#!/bin/bash
# Quick pod analysis script

POD_NAME=$1
NAMESPACE=${2:-production}

echo "Analyzing pod: $POD_NAME in namespace: $NAMESPACE"
echo "================================================"

# Get pod details
echo "1. Getting pod description..."
POD_DESC=$(kubectl describe pod $POD_NAME -n $NAMESPACE)

echo "2. Getting pod logs..."
POD_LOGS=$(kubectl logs $POD_NAME -n $NAMESPACE --tail=50 2>/dev/null || echo "No logs available")

# Send to Claude
wibey chat --model sonnet "
Analyze this Kubernetes pod issue:

POD DESCRIPTION:
$POD_DESC

POD LOGS:
$POD_LOGS

Give me: root cause, immediate fix, and prevention steps.
"
```

**Usage:**
```bash
chmod +x analyze_pod.sh
./analyze_pod.sh payment-service-5f7d9c production
```

### Step 3.3: Create Configuration File for Wibey

**Create file: `wibey_config.yaml`**

```yaml
# Wibey Configuration for Incident Analysis

default_model: sonnet
timeout: 300  # 5 minutes

# Model-specific settings
models:
  haiku:
    use_for: quick_checks, simple_parsing, status_checks
    timeout: 30
  
  sonnet:
    use_for: troubleshooting, analysis, code_review
    timeout: 120
  
  opus:
    use_for: complex_issues, architecture_decisions
    timeout: 300

# Incident categories
incidents:
  kubernetes:
    model: sonnet
    template: TEMPLATE_1_K8S_POD_CRASH.txt
  
  azure:
    model: sonnet
    template: TEMPLATE_2_AKS_CLUSTER.txt
  
  monitoring:
    model: sonnet
    template: TEMPLATE_3_PROMETHEUS_GRAFANA.txt
  
  deployment:
    model: sonnet
    template: TEMPLATE_4_DEPLOYMENT_RELEASE.txt
  
  network:
    model: sonnet
    template: TEMPLATE_5_NETWORK_CONNECTIVITY.txt
  
  resources:
    model: sonnet
    template: TEMPLATE_6_RESOURCE_CONSTRAINTS.txt
  
  logs:
    model: sonnet
    template: TEMPLATE_7_LOG_ANALYSIS.txt

# Default behavior
save_responses: true
save_directory: ~/claude-incident-templates/resolved-incidents
include_timestamp: true
```

---

## PHASE 4: TEST RUN & VALIDATION {#phase-4}

### Step 4.1: Test Template 1 - K8s Pod Crash

**Scenario**: You have a pod that's crashing

```bash
# Navigate to templates
cd ~/claude-incident-templates

# Get a real pod that's having issues (or use a test pod)
kubectl get pods -n production | grep -i "crash\|error\|pending" | head -1

# Get pod details
kubectl describe pod [POD_NAME] -n production > /tmp/pod_describe.txt

# Run template
wibey chat --model sonnet "
$(cat kubernetes/TEMPLATE_1_K8S_POD_CRASH.txt)

# Fill in your data:
Environment:
- Platform: Azure AKS
- Namespace: production
- Pod name: [YOUR_POD_NAME]
- Application: [YOUR_APP]

Current Status:
- Pod State: [GET FROM: kubectl get pods -n production]
- Restart count: [FROM DESCRIBE OUTPUT]
- Age: [FROM DESCRIBE OUTPUT]

Error Messages:
$(cat /tmp/pod_describe.txt)

What I've Already Tried:
1. Restarted pod
2. Checked logs
3. Verified image exists

I need root cause and fix.
"
```

**Expected Output:**
- Claude analyzes your pod issue
- Provides root cause
- Gives immediate fix steps
- Suggests prevention measures

### Step 4.2: Test Template 3 - Monitoring

```bash
# Test with a simple alert
wibey chat --model sonnet "
$(cat monitoring/TEMPLATE_3_PROMETHEUS_GRAFANA.txt)

# Fill in:
Monitoring Stack:
- Prometheus version: $(kubectl get deployment prometheus -n monitoring -o jsonpath='{.spec.template.spec.containers[0].image}' 2>/dev/null || echo "2.40.5")
- Grafana version: $(kubectl get deployment grafana -n monitoring -o jsonpath='{.spec.template.spec.containers[0].image}' 2>/dev/null || echo "9.5.3")

Problem:
I want to write a simple alert for high CPU usage (>80% for 5 mins). What's the PromQL query?

I need just a working query for this scenario.
"
```

### Step 4.3: Validate Output Quality

After each test, check:

- [ ] Response is specific to your environment
- [ ] Solution is actionable (not generic)
- [ ] Includes verification steps
- [ ] Response time is < 60 seconds
- [ ] Format is clear and well-organized

**If all checks pass** → Move to Phase 5

---

## PHASE 5: TEAM INTEGRATION {#phase-5}

### Step 5.1: Create a Team Incident Response Guide

**Create file: `TEAM_INCIDENT_RUNBOOK.md`**

```markdown
# Team Incident Response Guide
## Using Claude with Wibey CLI

### When an Incident Occurs:

1. **Identify the incident type** (use Quick Reference Card)
2. **Copy the matching template**
3. **Paste into Wibey CLI:**
   ```bash
   wibey chat --model sonnet "[TEMPLATE]"
   ```
4. **Fill in your specific data**
5. **Get instant analysis & fix steps**

### Template Quick Links:

- **Pod crashing?** → Use TEMPLATE_1
- **Cluster issues?** → Use TEMPLATE_2
- **Alerts not working?** → Use TEMPLATE_3
- **Deployment failing?** → Use TEMPLATE_4
- **Can't reach service?** → Use TEMPLATE_5
- **Running out of resources?** → Use TEMPLATE_6
- **Performance slow?** → Use TEMPLATE_7

### Escalation Path:

1. Try template + Haiku model (30 sec)
2. Try template + Sonnet model (2 min)
3. Try Opus model for complex issues (5 min)
4. Escalate to on-call if still unresolved

### Saving Responses:

```bash
# Save analysis to file
wibey chat --model sonnet "[TEMPLATE]" > incident_YYYY-MM-DD_HH-MM.txt

# Save to team wiki/knowledge base
# Tag with: incident-type, severity, resolution
```

### Team Knowledge Base:

Store resolved incidents in:
```
~/claude-incident-templates/resolved-incidents/
```

Format:
```
incident_2024-08-29_14-30_pod-crash_payment-service.txt
incident_2024-08-29_15-45_network_connectivity_db.txt
incident_2024-08-29_16-20_prometheus_alert_cpu.txt
```
```

### Step 5.2: Share with Team

```bash
# Create a package for team
zip -r claude-templates-for-team.zip \
  INCIDENT_PROMPT_TEMPLATES_GUIDE.md \
  QUICK_REFERENCE_CARD.txt \
  TEMPLATE_*.txt \
  TEAM_INCIDENT_RUNBOOK.md \
  wibey_config.yaml

# Share via:
# - Confluence/Wiki
# - Slack
# - Git repo
# - Email to team
```

### Step 5.3: Create Team Training Session

**Suggested agenda (30 minutes):**

1. **Introduction** (5 min)
   - What is Claude + Wibey
   - Why it helps with incidents

2. **Demo** (10 min)
   - Live demo: K8s pod crash template
   - Show Wibey CLI usage
   - Show response quality

3. **Hands-on** (10 min)
   - Team tries one template
   - Ask questions

4. **Q&A** (5 min)
   - Address concerns
   - Share knowledge base location

---

## TROUBLESHOOTING COMMON ISSUES {#troubleshooting}

### Issue 1: Wibey Command Not Found

**Error:**
```
Command 'wibey' not found
```

**Solutions:**
```bash
# Check if Wibey is installed
which wibey

# Add to PATH if needed
export PATH=$PATH:/path/to/wibey/bin

# Check Anthropic API access
wibey login  # If needed

# Verify you have permissions
wibey models list  # Should show: haiku, sonnet, opus
```

**Contact**: TCS Wibey administrator

---

### Issue 2: Template Placeholder Not Replaced

**Problem:**
```
I pasted [POD_NAME] instead of actual pod name
```

**Solution:**
```bash
# Create a template with your values pre-filled
sed -i 's/\[YOUR_CLUSTER\]/prod-aks-central/g' TEMPLATE_1_K8S_POD_CRASH.txt
sed -i 's/\[YOUR_NAMESPACE\]/production/g' TEMPLATE_1_K8S_POD_CRASH.txt

# Or use your customizations file
cat MY_CUSTOMIZATIONS.txt  # Reference while filling template
```

---

### Issue 3: Response Takes Too Long

**Problem:**
```
Wibey chat command hanging for > 2 minutes
```

**Solutions:**
```bash
# Check API connectivity
ping api.anthropic.com

# Try with Haiku (faster model)
wibey chat --model haiku "[TEMPLATE]"

# Check Wibey logs
wibey logs  # If available

# Timeout issue - increase timeout
wibey chat --model sonnet --timeout 300 "[TEMPLATE]"
```

---

### Issue 4: Claude Asks for More Information

**What Claude might ask:**
```
"Can you provide the exact error message from kubectl describe?"
"What image is the pod trying to pull?"
"When did this issue start?"
```

**How to respond:**
```bash
# Provide the specific information
# Use kubectl to get exact output:
kubectl describe pod [POD_NAME] -n [NAMESPACE] | grep -A 20 "Events:"

# Then re-run template with the specific error
wibey chat --model sonnet "
[TEMPLATE]
...
Error Messages:
[PASTE EXACT OUTPUT]
"
```

---

### Issue 5: Response Doesn't Help

**What you might see:**
```
- Generic response not specific to your cluster
- Suggestions you've already tried
- Unclear or confusing explanation
```

**How to fix:**
```bash
# Provide MORE context in template
# Include:
# - Exact error messages (copy-paste, not paraphrase)
# - What you've already tried
# - Your environment details
# - Recent changes

# Try again with Opus model (more capable)
wibey chat --model opus "[TEMPLATE]"

# Or ask a follow-up question
wibey chat --model sonnet "
Based on your previous analysis, I also see this error: [ERROR]
What does this change?
"
```

---

### Issue 6: Template Too Long

**Problem:**
```
Template has too many sections for quick answer
```

**Solution:**
```bash
# Use shortened version for quick fixes
wibey chat --model haiku "
Pod [NAME] in [NAMESPACE] is [STATE].
Error: [ERROR_MESSAGE]
What's the quick fix?
"

# Or use Opus for in-depth analysis
wibey chat --model opus "$(cat TEMPLATE_1_K8S_POD_CRASH.txt)"
```

---

### Issue 7: API Rate Limiting

**Error:**
```
Rate limit exceeded. Please wait before next request.
```

**Solution:**
```bash
# Space out requests (Wibey handles this)
# Or try again after 1 minute

# Save responses for team to reference
wibey chat --model sonnet "[TEMPLATE]" > incident_analysis.txt

# Share saved responses instead of re-running
cat incident_analysis.txt | wibey chat --model sonnet "Summarize this for my team"
```

---

## QUICK START SUMMARY

### First Day Setup (20 minutes):

1. ✅ Download all template files
2. ✅ Verify Wibey CLI works
3. ✅ Create working directory
4. ✅ Test one template with real incident
5. ✅ Save successful response

### First Week:

- Use templates for each incident type
- Build your incident library
- Share successful resolutions with team
- Refine templates based on your needs

### First Month:

- Incidents resolved 3x faster
- Team trained on process
- Personal knowledge base built
- Templates customized for your environment

---

## VALIDATION CHECKLIST

Before declaring "Setup Complete", verify:

- [ ] Wibey CLI installed and working
- [ ] All 7 templates downloaded
- [ ] Working directory created and organized
- [ ] Tested at least one template with real incident
- [ ] Response was helpful and specific
- [ ] Saved response successfully
- [ ] Can locate templates quickly
- [ ] Team members notified of new process
- [ ] Quick Reference Card bookmarked
- [ ] My_Customizations.txt created

**✓ All checked?** You're ready to use Claude for incident management!

---

## NEXT STEPS

1. **Today**: Complete Phase 1-4
2. **This Week**: Use templates for 2-3 real incidents
3. **Next Week**: Train team on process
4. **Ongoing**: Build personal incident library

---

## SUPPORT & RESOURCES

### If You Get Stuck:

1. **Check QUICK_REFERENCE_CARD.txt** - Has most answers
2. **Check INCIDENT_PROMPT_TEMPLATES_GUIDE.md** - Full documentation
3. **Review resolved incidents** - See similar issues
4. **Try different model** - Haiku → Sonnet → Opus
5. **Ask Claude directly** - "Help me troubleshoot [issue]"

### Key Files Locations:

```
~/claude-incident-templates/
├── README.txt (this file)
├── QUICK_REFERENCE_CARD.txt
├── INCIDENT_PROMPT_TEMPLATES_GUIDE.md
├── MY_CUSTOMIZATIONS.txt
└── resolved-incidents/
    ├── incident_2024-08-29_14-30_*.txt
    └── ... (your saved responses)
```

---

**You're all set! Happy incident troubleshooting! 🚀**

*Last updated: 2024-08-29*
*Version: 1.0*
