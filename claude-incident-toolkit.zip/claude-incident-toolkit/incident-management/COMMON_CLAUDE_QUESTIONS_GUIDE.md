# COMMON CLAUDE QUESTIONS & HOW TO ANSWER THEM
## What Claude Might Ask When Analyzing Your Incidents

**Objective**: Help you understand and prepare for Claude's follow-up questions  
**Value**: Speed up incident resolution by having answers ready  
**Time to read**: 10 minutes

---

## TABLE OF CONTENTS

1. [About Claude's Question Style](#about-claude)
2. [Question Category 1: Clarification Questions](#category-1)
3. [Question Category 2: Technical Deep-Dives](#category-2)
4. [Question Category 3: Environment & Context](#category-3)
5. [Question Category 4: Verification & Validation](#category-4)
6. [Question Category 5: Decision & Action](#category-5)
7. [Question Category 6: Root Cause Analysis](#category-6)
8. [Pre-Emptive Answers (Save Time!)](#pre-emptive)
9. [Example Conversations](#examples)
10. [Quick Answer Reference](#quick-ref)

---

## ABOUT CLAUDE'S QUESTION STYLE {#about-claude}

### Why Claude Asks Questions

Claude asks follow-up questions to:
- **Get exact error messages** (not paraphrased summaries)
- **Understand your environment** (cluster setup, configs)
- **Confirm what you've tried** (to avoid wasted steps)
- **Identify missing information** (that would improve the diagnosis)
- **Clarify ambiguity** (multiple possible causes)

### Good News!

If you use the templates and provide:
✅ Exact error messages  
✅ Complete kubectl output  
✅ What you've already tried  
✅ Environment details  

Claude will ask **fewer follow-up questions** and give you the answer **faster**.

---

## QUESTION CATEGORY 1: CLARIFICATION QUESTIONS {#category-1}

These are Claude's most common questions. They're asking for **exact text**, not summaries.

### 1.1 "Can you provide the exact error message?"

**What Claude is asking for:**
```
The EXACT text from the error, including timestamps and error codes.
NOT a paraphrase or summary.
```

**Example Bad Answer (Paraphrase):**
```
"The pod couldn't start"
"The image didn't pull"
"There was a connection error"
```

**Example Good Answer (Exact):**
```
Failed to pull image "myacr.azurecr.io/payment-svc:1.2.3": 
rpc error: code = Unknown desc = Error response from daemon: 
unauthorized: authentication required
```

**How to get the exact error:**

```bash
# For pod errors
kubectl describe pod [POD_NAME] -n [NAMESPACE] | grep -A 10 "Status:"

# For image pull errors  
kubectl describe pod [POD_NAME] -n [NAMESPACE] | grep -A 5 "Events:"

# For logs
kubectl logs [POD_NAME] -n [NAMESPACE] --tail=100

# For API errors
kubectl get pods -o yaml [POD_NAME] -n [NAMESPACE] | grep -A 20 "status:"

# Copy the ENTIRE block, not just one line
```

**Quick Reference - Copy This:**
```bash
# Complete pod analysis
kubectl describe pod [YOUR_POD] -n [NAMESPACE] > /tmp/pod_analysis.txt
cat /tmp/pod_analysis.txt  # Copy entire output to Claude
```

---

### 1.2 "What does the pod/node status show?"

**Claude wants:**
```
Output from: kubectl get pods -n [namespace] -o wide
OR: kubectl get nodes -o wide
```

**Example:**
```
NAME                       READY   STATUS             RESTARTS   AGE   IP           NODE
payment-service-5f7d9c     0/1     CrashLoopBackOff   47         3h    10.0.8.45    aks-system-1
```

**How to answer:**
```bash
# Show pod status
kubectl get pods -n production -o wide

# Show node status  
kubectl get nodes -o wide

# Show both together
kubectl get pods -A -o wide | grep -E "(Error|CrashLoop|Pending|Terminating)"
```

---

### 1.3 "What exactly changed recently?"

**Claude wants specific details:**

**Not specific:**
- "We deployed something"
- "Someone changed the config"
- "We updated recently"

**Specific:**
- "Deployed v2.5.1 2 hours ago, previously v2.5.0 was working"
- "Applied network policy 'default-deny' yesterday"
- "Scaled replicas from 2 to 3 this morning"

**How to answer:**
```bash
# Show recent deployments
kubectl rollout history deployment/[NAME] -n [NAMESPACE]

# Show deployment changes
kubectl rollout history deployment/[NAME] -n [NAMESPACE] --revision=1

# Check what changed in config
kubectl get deployment [NAME] -n [NAMESPACE] -o yaml | grep -A 5 "image:"

# Check recent events
kubectl get events -n [NAMESPACE] --sort-by='.lastTimestamp' | tail -20
```

---

### 1.4 "Is this pod new or existing?"

**Why Claude asks:**
- New pods often have different failure modes
- Existing pods that suddenly fail point to changes

**How to answer:**
```bash
# Check pod age
kubectl get pods -n [NAMESPACE] -o wide | grep [POD_NAME]

# Check creation time
kubectl get pod [POD_NAME] -n [NAMESPACE] -o jsonpath='{.metadata.creationTimestamp}'

# Check deployment status
kubectl rollout status deployment/[NAME] -n [NAMESPACE]
```

**Good answer examples:**
- "This is a brand new pod, deployed 15 minutes ago for the first time"
- "This pod has been running for 3 days fine, just started crashing 1 hour ago"
- "This is part of a rolling update - old pods (v2.5.0) work fine, new pods (v2.5.1) all crash"

---

## QUESTION CATEGORY 2: TECHNICAL DEEP-DIVES {#category-2}

Claude asks these when the surface-level info isn't enough.

### 2.1 "What are the resource limits set for this pod?"

**Claude needs:**
- CPU requests
- Memory requests  
- CPU limits
- Memory limits

**How to answer:**
```bash
# Get resource details
kubectl describe pod [POD_NAME] -n [NAMESPACE] | grep -A 5 "Limits\|Requests"

# Full YAML format
kubectl get pod [POD_NAME] -n [NAMESPACE] -o yaml | grep -A 10 "resources:"

# Example output to share with Claude:
Limits:
  cpu: 500m
  memory: 1Gi
Requests:
  cpu: 250m
  memory: 512Mi
```

**Why this matters:**
- Memory limit too low → OOMKilled
- CPU requests too high → can't schedule
- No limits set → pod can consume everything

---

### 2.2 "What does the application log say?"

**Claude needs:**
- Last 50-100 lines of logs
- With timestamps
- Including ERROR and WARNING lines
- Context around the error

**How to answer:**
```bash
# Get recent logs
kubectl logs [POD_NAME] -n [NAMESPACE] --tail=100

# Get logs with timestamps
kubectl logs [POD_NAME] -n [NAMESPACE] --timestamps=true --tail=100

# If pod has multiple containers
kubectl logs [POD_NAME] -c [CONTAINER_NAME] -n [NAMESPACE] --tail=100

# Get logs from previous pod (if it crashed)
kubectl logs [POD_NAME] -n [NAMESPACE] --previous

# Save to file for Claude
kubectl logs [POD_NAME] -n [NAMESPACE] --tail=100 > /tmp/pod_logs.txt
cat /tmp/pod_logs.txt  # Copy entire output
```

**What good logs look like:**
```
2024-08-29T14:35:12.456Z [INFO] Starting application server on port 8080
2024-08-29T14:35:13.789Z [INFO] Connected to database: postgres://db:5432
2024-08-29T14:35:45.012Z [ERROR] Connection refused: unable to reach cache service
2024-08-29T14:35:46.134Z [WARN] Retrying connection (attempt 1/3)
2024-08-29T14:35:47.256Z [ERROR] Max retries exceeded, shutting down
```

---

### 2.3 "What's the network connectivity like?"

**Claude wants you to test:**

```bash
# DNS resolution
kubectl exec [POD] -n [NAMESPACE] -- nslookup [SERVICE_NAME]

# Direct connectivity
kubectl exec [POD] -n [NAMESPACE] -- curl -v http://[SERVICE]:8080

# Ping test
kubectl exec [POD] -n [NAMESPACE] -- ping [SERVICE]

# Check from another pod
kubectl exec -it deployment/[OTHER_POD] -n [NAMESPACE] -- curl http://[SERVICE]:8080
```

**Example answer:**
```
From payment-service pod to postgres-db service:
- DNS resolution: WORKS (resolves to 10.0.8.45)
- Ping: FAILS (Connection refused)
- Curl: FAILS with "Connection refused on port 5432"
- From different pod: ALSO FAILS

This indicates: Network policy or service misconfiguration
```

---

### 2.4 "How much resource is it actually using?"

**Claude wants:**
- Current memory/CPU usage
- Peak usage
- Trend (increasing/stable/decreasing)

**How to answer:**
```bash
# Current usage
kubectl top pods -n [NAMESPACE] | grep [POD_NAME]

# Current usage with requested limits
kubectl top pods -n [NAMESPACE] --containers

# Historical data from Prometheus
# (if available)
memory_usage_percent = (current_memory / limit_memory) * 100
cpu_usage_percent = (current_cpu / limit_cpu) * 100
```

**Example answer:**
```
Current Usage:
- Memory: 892Mi (88% of 1Gi limit)
- CPU: 250m (50% of 500m limit)

Peak (from monitoring):
- Memory: 1.2Gi (exceeded limit 20 minutes ago)
- CPU: 450m (peak at deployment time)

Trend:
- Memory increasing by ~100Mi per day
- CPU stable around 200-300m
```

---

## QUESTION CATEGORY 3: ENVIRONMENT & CONTEXT {#category-3}

These questions help Claude understand your specific setup.

### 3.1 "What's your Kubernetes version?"

**How to answer:**
```bash
# Cluster version
kubectl version

# Node versions
kubectl get nodes -o wide

# Server version only
kubectl version --short

# Example answer:
Server Version: v1.27.4
```

---

### 3.2 "What monitoring/observability tools do you have?"

**Common answers for you:**
```
Monitoring Stack:
- Prometheus: 2.40.5 (metrics)
- Grafana: 9.5.3 (dashboards)
- OpenObserve: [version] (log aggregation)
- AlertManager: YES (alert routing)
```

**How to check:**
```bash
# Check installed monitoring
kubectl get namespaces | grep -E "monitor|observ"

# Check Prometheus
kubectl get pods -n monitoring | grep prometheus

# Check Grafana
kubectl get pods -n monitoring | grep grafana

# Check what version
kubectl get deployment prometheus -n monitoring -o yaml | grep image:
```

---

### 3.3 "How is your cluster configured?"

**What Claude might ask:**
- Networking: CNI type (Azure CNI, Calico)
- Storage: CSI driver
- Ingress: What ingress controller
- Load balancer: Azure LB, Nginx Ingress
- Network policies: Enabled/disabled

**How to answer:**
```bash
# Network plugins
kubectl get pods -n kube-system | grep -E "calico|flannel|cilium|cni"

# Ingress controller
kubectl get pods -A | grep ingress

# Storage
kubectl get storageclasses

# Example answer:
Network: Azure CNI (native Azure networking)
Ingress: Nginx Ingress Controller (nginx/ingress-nginx)
Storage: Azure Disk CSI driver
```

---

### 3.4 "Is this a multi-tenant or shared cluster?"

**Why Claude asks:**
- Multi-tenant → namespace isolation matters
- Shared → resource contention possible

**How to answer:**
```bash
# See all namespaces
kubectl get namespaces

# Example answer:
"Shared cluster with 5 production namespaces:
- namespace: payment (our team)
- namespace: authentication
- namespace: notifications
- kube-system
- monitoring"
```

---

## QUESTION CATEGORY 4: VERIFICATION & VALIDATION {#category-4}

Claude asks these to confirm the fix worked.

### 4.1 "How do you verify the pod is healthy now?"

**Claude wants you to check:**

```bash
# Check pod status is Running
kubectl get pods -n [NAMESPACE] | grep [POD_NAME]

# Check pod is Ready
kubectl get pods -n [NAMESPACE] -o wide | grep [POD_NAME]

# Check it's not restarting
kubectl describe pod [POD_NAME] -n [NAMESPACE] | grep "Restart Count"

# Check logs are healthy
kubectl logs [POD_NAME] -n [NAMESPACE] --tail=20

# Example answer:
kubectl get pods -n production | grep payment-service
payment-service-5f7d9c     1/1     Running   0          5m   10.0.8.45

✅ Pod Running
✅ Not restarting (Restart Count: 0)  
✅ Logs show: "Server started on :8080"
✅ Ready: 1/1
```

---

### 4.2 "Can you test the fix is working?"

**Claude might ask you to test:**

```bash
# Test application is responding
kubectl exec [POD] -n [NAMESPACE] -- curl http://localhost:8080/health

# Test connectivity to dependency
kubectl exec [POD] -n [NAMESPACE] -- curl http://[SERVICE]:5432

# Test from outside the pod
kubectl port-forward pod/[POD] 8080:8080 -n [NAMESPACE]
curl http://localhost:8080

# Example answer:
Application health check:
$ kubectl exec payment-service-5f7d9c -n production -- curl http://localhost:8080/health

HTTP/1.1 200 OK
{"status": "healthy", "uptime": "5m"}

✅ Service responding
✅ Health check passing
```

---

### 4.3 "How do you prevent this from happening again?"

**Claude might ask you to set up monitoring:**

```bash
# Set up resource alerts
# Set up pod restart alerts
# Set up image pull failure alerts

Example answer:
"I've set up these alerts in Prometheus:
1. pod_restart_rate > 1/hour → alert
2. pod_memory_usage > 90% limit → alert
3. image_pull_errors > 0 → alert"
```

---

## QUESTION CATEGORY 5: DECISION & ACTION {#category-5}

Claude asks these to get your approval before suggesting drastic actions.

### 5.1 "Should we rollback or fix forward?"

**Claude wants to know:**

```
- How critical is this service?
- How many users affected?
- Can we afford downtime?
- Can we fix it quickly?
```

**How to answer:**
```
"Payment service is CRITICAL. 
5,000 transactions/hour blocked.
We need fix in < 15 minutes or rollback.

Previous version (v2.5.0) was working fine 1 hour ago.
Current version (v2.5.1) has this bug.

Recommendation: Let's try quick fix first (5 min),
if that doesn't work, rollback (2 min)."
```

---

### 5.2 "Can we restart the pod/node?"

**Claude wants to know:**

```bash
- Is this a production pod?
- Will restart cause downtime?
- Are there replicas/backup instances?
```

**How to answer:**
```bash
# Check replica count
kubectl get deployment [NAME] -n [NAMESPACE]

"This deployment has 3 replicas.
Restarting one pod will:
- Take ~1 minute
- Cause brief traffic hiccup (~100ms)
- But won't cause downtime (other replicas running)

YES, safe to restart."
```

---

### 5.3 "Should we scale up the cluster?"

**Claude asks this for resource issues:**

```bash
# Check if nodes are full
kubectl describe nodes

# Check pending pods
kubectl get pods -A | grep Pending

"Cluster has 3 nodes, all at 85% CPU.
5 pods pending (can't schedule).
Recommendation: Scale to 4 nodes (adds 33% capacity)"
```

---

## QUESTION CATEGORY 6: ROOT CAUSE ANALYSIS {#category-6}

Claude asks these to dig deeper into WHY something happened.

### 6.1 "When exactly did this start?"

**Claude wants specific timeline:**

```
NOT: "A few hours ago"
YES: "2024-08-29T14:35:12Z when we deployed v2.5.1"

How to find:
- Check pod creation time
- Check deployment history
- Check pod restart times
```

**Commands:**
```bash
# Pod creation time
kubectl get pod [POD] -n [NAMESPACE] -o jsonpath='{.metadata.creationTimestamp}'

# All pod restarts (shows timeline)
kubectl describe pod [POD] -n [NAMESPACE] | grep -A 50 "Events:"

# Deployment history
kubectl rollout history deployment/[NAME] -n [NAMESPACE]
```

---

### 6.2 "What was different before?"

**Claude is looking for changes:**

```bash
# Compare current vs previous deployment
kubectl rollout history deployment/[NAME] -n [NAMESPACE] --revision=X

# See what config changed
kubectl diff -f [OLD_YAML] [NEW_YAML]

# Or manually:
"Changes in deployment v2.5.1:
- Image: payment-svc:2.5.0 → payment-svc:2.5.1
- Memory: 512Mi → 1Gi (we increased limit)
- Replicas: 2 → 3
- No config changes"
```

---

### 6.3 "Is this a known issue?"

**Claude might ask:**

```
Do you have:
- Previous similar incidents?
- Documentation about this error?
- Known workarounds?
```

**How to answer:**
```
"Yes! We had similar issue 2 months ago:
- Pod crashed with same ImagePullBackOff error
- Root cause was: ACR authentication expired
- Fix was: Refresh the imagePullSecret
- We added to runbook with alert"
```

---

## PRE-EMPTIVE ANSWERS (Save Time!) {#pre-emptive}

### Answer These BEFORE Claude Asks

If you include these in your templates, Claude won't need to ask:

**✅ Always Include:**
```
1. EXACT error message (copy-paste from describe/logs)
2. What you've already tried (prevent wasted steps)
3. When it started (specific time)
4. Recent changes (deployment/config changes)
5. Environment details (cluster name, namespace, app name)
6. Resource limits (CPU/memory)
7. Pod status (Running/CrashLoop/Pending/etc)
```

**✅ For Specific Scenarios:**

**Pod Crashes:**
```
- Resource limits configured
- Pod logs (last 50 lines)
- Pod describe output
- When it started crashing
```

**Network Issues:**
```
- Proof DNS resolves
- Proof application is running
- Network policy rules
- Firewall rules (if applicable)
```

**Monitoring Issues:**
```
- Full alert rule/query
- Target status (is Prometheus scraping?)
- When alert stopped working
- Recent Prometheus/Grafana changes
```

---

## EXAMPLE CONVERSATIONS {#examples}

### Example 1: Pod Crash (Minimal Back-and-Forth)

**Your Initial Message:**
```
Role: DevOps engineer

Pod payment-service-5f7d9c is CrashLoopBackOff
Restart count: 47, Age: 3 hours

Error (from kubectl describe):
ImagePullBackOff - Failed to pull image 
"myacr.azurecr.io/payment-svc:1.2.3": 
rpc error: code = Unknown desc = 
Error response from daemon: unauthorized

What I've tried:
1. Verified image exists in ACR ✓
2. Verified imagePullSecret is correct ✓
3. az acr login --name myacr ✓ (success)
4. Manually pulled image locally ✓ (success)

Need: Why can't pod pull if I can?
```

**Claude's Response:**
This is usually enough detail! Claude will likely:
- Identify the ACR auth secret is stale
- Give you exact fix steps
- Ask: "Did rotating the secret help?"

**Your Follow-up:**
```
Rotated the secret, pod now Running.
But how do I prevent this?
```

**Claude helps you set up alerts.**

---

### Example 2: Network Issue (More Questions)

**Your Initial:**
```
App pod can't reach database.
Error: connection refused on port 5432

Tried:
- ping postgres-db → fails
- nslookup → works (resolves to IP)
```

**Claude Asks:**
```
1. What's the exact error from the application?
2. Can other pods reach the database?
3. Are network policies enabled?
4. What namespace is the database in?
```

**Why? Claude needs to know:**
- Application issue vs network issue
- If it's cluster-wide or specific to your pod
- If network policy is blocking
- If it's a namespace isolation issue

**Your Answer:**
```
1. Error: "Connection refused" when app tries curl postgres-db:5432
2. Database team confirmed: other pods CAN reach it
3. Network policies: YES, enabled (I can show rules)
4. Database: kube-system namespace, app: production namespace

Specifically this is only failing for MY pod.
```

**Claude Analyzes:**
"Network policy is blocking your pod but not others. 
The rule might be too specific. Let me show you what changed..."

---

### Example 3: Monitoring Issue (Complex)

**Your Initial:**
```
Pod CPU alert not firing.
Pods hitting 95% CPU in Grafana dashboard.
Alert rule not triggering.

Query:
(sum(rate(container_cpu_usage_seconds_total{namespace="production"}[5m])) by (pod) / 
sum(container_spec_cpu_quota{namespace="production"}) by (pod)) > 0.9

Prometheus targets: All UP
```

**Claude Asks:**
```
1. When you manually run that query, what does it return?
2. What timeframe are you checking?
3. Did this alert work before? When did it stop?
```

**Your Answer:**
```
1. Query returns: 0 results (empty)
2. Current time: 2024-08-29T15:00:00Z
3. Alert worked last week, stopped yesterday
   (when we applied new resource quota policy)

The query is broken - it's not finding any data even though
metrics exist (I can see them in other queries).
```

**Claude Analyzes:**
"The resource quota added a label. Your query uses old label names.
Here's the fixed query that accounts for the new labels..."

---

## QUICK ANSWER REFERENCE {#quick-ref}

### Copy These Commands

When Claude asks:

| Claude Asks | Run This | Copy Output |
|-------------|----------|------------|
| Pod status | `kubectl get pods -n [NS] -o wide` | Entire table |
| Error message | `kubectl describe pod [P] -n [NS]` | Events section |
| Pod logs | `kubectl logs [P] -n [NS] --tail=100` | Last 100 lines |
| Resource usage | `kubectl top pods -n [NS]` | All pods in namespace |
| What changed | `kubectl rollout history deployment/[D] -n [NS]` | All revisions |
| Network test | `kubectl exec [P] -- nslookup [S]` | Full output |
| Cluster status | `kubectl get nodes -o wide` | Entire table |

### Pre-Made Answers (Fill In Your Values)

**Quick Pod Status:**
```bash
kubectl get pods -n production -o wide | grep [POD_NAME]
kubectl describe pod [POD_NAME] -n production | grep -A 5 "Image:"
kubectl logs [POD_NAME] -n production --tail=50
```

**Quick Cluster Status:**
```bash
kubectl get nodes -o wide
kubectl get pods -A | grep -E "Error|Pending|CrashLoop"
kubectl top nodes
```

**Quick Monitoring Status:**
```bash
kubectl get pods -n monitoring
kubectl logs -n monitoring deployment/prometheus --tail=20
kubectl logs -n monitoring deployment/grafana --tail=20
```

---

## SUMMARY

### Claude Will Ask About:

1. **Exact errors** - Copy-paste them, don't paraphrase
2. **What you tried** - Saves time, prevents repeated suggestions
3. **Environment details** - Cluster version, tools, config
4. **Proof/Evidence** - kubectl outputs, logs, metrics
5. **Timeline** - When exactly did it start?
6. **Recent changes** - What was different before?
7. **Verification** - How do we know it's fixed?

### How to Answer Faster:

✅ Include all info in first message  
✅ Use exact text, not summaries  
✅ Mention what you've already tried  
✅ Provide timestamps for events  
✅ Share actual command outputs  
✅ State constraints (can't restart/rollback/scale)  

### If You're Stuck:

- Paste the exact error to Claude
- Run suggested kubectl commands
- Share the exact output
- Claude will usually find the answer

---

**Pro Tip**: The more specific your first message, the fewer follow-up questions you'll get. Most incidents can be solved with just 1-2 exchanges!

---

*Keep this guide handy when troubleshooting. Reference it when Claude asks something unexpected.*
