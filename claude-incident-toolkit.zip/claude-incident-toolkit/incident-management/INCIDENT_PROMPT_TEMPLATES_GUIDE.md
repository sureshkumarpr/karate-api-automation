# Incident Prompt Templates for DevOps/Production Support
## Using Wibey CLI with Claude Models

**Version**: 1.0  
**Created for**: Sureshkumar @ TCS (Production Support Executive & DevOps Engineer)  
**Best with**: Sonnet model (balanced speed & depth) or Opus (complex issues)

---

## Table of Contents
1. [How to Use These Templates](#how-to-use)
2. [Template Categories](#categories)
3. [Individual Templates](#templates)
4. [Quick Copy-Paste Guide](#quick-reference)

---

## How to Use These Templates {#how-to-use}

### Step 1: Copy the Template
- Find the template matching your incident type below
- Copy the entire template text

### Step 2: Paste into Wibey CLI
```bash
wibey chat --model sonnet "
[PASTE TEMPLATE HERE]
"
```

### Step 3: Fill in Your Variables
Replace placeholders like:
- `[PASTE ERROR LOG]` → Your actual error message
- `[DESCRIBE WHAT YOU'VE TRIED]` → Your troubleshooting steps
- `[YOUR ENVIRONMENT DETAILS]` → Your setup specifics

### Step 4: Hit Enter
Claude will respond with diagnosis, fix, and prevention.

---

## Template Categories {#categories}

1. **Kubernetes Pod Issues** (CrashLoopBackOff, OOMKilled, ImagePullBackOff)
2. **Azure AKS Cluster Issues** (Node failures, scaling, quota)
3. **Monitoring & Alerting Issues** (Prometheus, Grafana, OpenObserve)
4. **Deployment Problems** (Failed releases, rollback needed)
5. **Network & Connectivity Issues** (Connection refused, DNS, timeouts)
6. **Resource Constraints** (CPU/Memory/Disk pressure)
7. **Log Analysis & Performance** (Analyzing logs, query optimization)

---

## Individual Templates {#templates}

---

### TEMPLATE 1: Kubernetes Pod Crash Troubleshooting

**Use when**: Pod is CrashLoopBackOff, Pending, or Error state  
**Model**: Sonnet  
**Time to fix**: Usually 3-5 minutes

```
Role: I'm a DevOps engineer with Kubernetes/AKS experience at TCS.

Incident: Kubernetes pod crash troubleshooting

Environment:
- Platform: Azure AKS
- Namespace: [production / staging / default]
- Pod name: [YOUR_POD_NAME]
- Application: [APP_NAME]

Current Status:
- Pod State: [CrashLoopBackOff / OOMKilled / ImagePullBackOff / Pending / Error]
- Restart count: [NUMBER]
- Age: [TIME]

Error Messages:
[PASTE COMPLETE ERROR LOG HERE - include describe output]

What I've Already Tried:
1. [ACTION 1 AND RESULT]
2. [ACTION 2 AND RESULT]
3. [ACTION 3 AND RESULT]

Additional Context:
- Recent changes: [DEPLOYMENT CHANGES / CONFIG CHANGES / NONE]
- Resource limits: CPU [VALUE], Memory [VALUE]
- Is this new pod or existing: [NEW / EXISTING]

I need:
1. Root cause analysis
2. Immediate fix (if it's urgent)
3. Verification steps
4. Prevention/prevention best practices

Format the response as:
## Root Cause
## Immediate Fix
## How to Verify It Works
## Prevention for Next Time
```

**Example filled-in version:**
```
Role: I'm a DevOps engineer with Kubernetes/AKS experience.

Incident: Kubernetes pod crash

Environment:
- Platform: Azure AKS
- Namespace: production
- Pod: payment-service-5f7d9c
- Application: Payment Processing Service

Current Status:
- Pod State: CrashLoopBackOff
- Restart count: 47
- Age: 3 hours

Error:
kubectl describe pod payment-service-5f7d9c -n production
Output: ImagePullBackOff - Failed to pull image "myacr.azurecr.io/payment-svc:1.2.3": rpc error: code = Unknown desc = Error response from daemon: unauthorized

What I've Tried:
1. Checked ACR credentials - they look correct in the secret
2. Ran: az acr login --name myacr -- success
3. Verified image exists in ACR -- it does

Additional Context:
- We deployed this 2 hours ago
- No ACR credential changes recently
- Resource limits: CPU 500m, Memory 512Mi

I need quick diagnosis and fix.
```

---

### TEMPLATE 2: Azure AKS Cluster Issues

**Use when**: Nodes failing, cluster unresponsive, scaling problems  
**Model**: Sonnet  
**Time to fix**: 5-10 minutes

```
Role: I'm a DevOps engineer managing Azure AKS clusters.

Incident: AKS Cluster Issue

Cluster Details:
- Cluster name: [CLUSTER_NAME]
- Region: [REGION]
- Kubernetes version: [VERSION]
- Node pool: [NAME] (Count: [NUM], Size: [VM_SIZE])

Problem Description:
[DESCRIBE THE ISSUE IN DETAIL]

Symptoms:
- Affected services: [LIST]
- Started: [WHEN]
- Current impact: [PODS CRASHING / NODES DOWN / SLOW / UNRESPONSIVE]

Metrics & Evidence:
- Node status: [PASTE: kubectl get nodes -o wide]
- Pod status: [PASTE: kubectl get pods -A | grep -i error/pending]
- Recent events: [PASTE: kubectl get events -A --sort-by='.lastTimestamp']
- AKS insights: [ANY ALERTS FROM AZURE PORTAL]

What I've Checked:
1. [CHECK 1 - RESULT]
2. [CHECK 2 - RESULT]
3. [CHECK 3 - RESULT]

Constraints:
- Can we scale/restart nodes: [YES/NO]
- Maintenance window: [AVAILABLE NOW/AFTER HRS]
- Critical services affected: [YES/NO - LIST]

I need:
1. Probable cause
2. Immediate mitigation (non-disruptive if possible)
3. Root fix steps
4. Post-incident checks

Format: ## Cause ## Immediate Fix ## Permanent Fix ## Validation Checklist
```

---

### TEMPLATE 3: Prometheus/Grafana Monitoring Issues

**Use when**: Alerts misfiring, missing metrics, query not working  
**Model**: Sonnet  
**Time to fix**: 3-7 minutes

```
Role: I'm a DevOps engineer managing Prometheus/Grafana monitoring.

Issue: Monitoring/Alerting Problem

Monitoring Stack:
- Prometheus version: [VERSION]
- Grafana version: [VERSION]
- AlertManager: [YES/NO]
- Scrape interval: [INTERVAL]
- Data retention: [DAYS]

Problem:
[DESCRIBE: Alerts not firing / Metrics missing / Query slow / Wrong values]

Current Query/Alert:
[PASTE YOUR PROMETHEUS QUERY OR ALERT RULE]

Expected Behavior:
[WHAT SHOULD HAPPEN]

Actual Behavior:
[WHAT'S ACTUALLY HAPPENING]

What I've Tried:
1. [TRIED AND RESULT]
2. [TRIED AND RESULT]

Additional Info:
- Prometheus targets status: [PASTE: /api/v1/targets from Prometheus]
- Relevant logs: [PASTE ERROR LOGS]
- When did this start: [TIME/DATE]
- Recent changes: [ANY CONFIG CHANGES]

I need:
1. Why isn't it working
2. How to fix the query/alert
3. How to validate the fix
4. Best practices for this scenario

Format: ## Problem Analysis ## Solution ## Validation Steps
```

**Common scenarios:**
```
# Alert not firing when it should
# Metrics showing wrong values
# Query timeout / performance issue
# Missing metrics from new application
# Need optimized query for large dataset
```

---

### TEMPLATE 4: Deployment & Release Issues

**Use when**: Deployment failed, rollback needed, traffic not routing  
**Model**: Sonnet  
**Time to fix**: 5-15 minutes

```
Role: I'm a DevOps engineer managing deployments to AKS.

Incident: Deployment Failure

Deployment Details:
- Application: [APP_NAME]
- Namespace: [NAMESPACE]
- Deployment name: [NAME]
- Release version: [VERSION]

Deployment Status:
[PASTE: kubectl describe deployment [NAME] -n [NAMESPACE]]
[PASTE: kubectl rollout history deployment/[NAME] -n [NAMESPACE]]

Issue:
[DESCRIBE: Deployment failed / Pods not starting / Traffic not routing / Rollback needed]

Pod Logs:
[PASTE: kubectl logs -f [POD_NAME] -n [NAMESPACE] --tail=100]

Rollout Status:
[PASTE: kubectl rollout status deployment/[NAME] -n [NAMESPACE]]

What Was Deployed:
- Image: [IMAGE_URL:TAG]
- Replicas: [DESIRED] (Current: [CURRENT], Ready: [READY])
- Strategy: [Rolling / Blue-Green / Canary]

Previous Version Status:
[WAS IT WORKING / WHEN DID IT LAST WORK]

What I've Tried:
1. [ACTION - RESULT]
2. [ACTION - RESULT]

I need:
1. Root cause of deployment failure
2. Should I rollback or fix forward
3. Detailed fix steps
4. How to verify traffic is flowing correctly
5. Post-deployment validation checklist

Format: ## Diagnosis ## Recommended Action ## Step-by-Step Fix ## Validation Checklist
```

---

### TEMPLATE 5: Network & Connectivity Issues

**Use when**: Connection refused, DNS not resolving, timeout errors  
**Model**: Sonnet  
**Time to fix**: 5-10 minutes

```
Role: I'm a DevOps engineer troubleshooting Kubernetes networking.

Issue: Network/Connectivity Problem

Environment:
- Cluster: [CLUSTER_NAME]
- Source pod: [POD_NAME] in namespace [NAMESPACE]
- Destination: [SERVICE_NAME / EXTERNAL_HOST / IP:PORT]
- Error: [CONNECTION REFUSED / TIMEOUT / DNS FAIL / etc]

Error Message:
[PASTE EXACT ERROR]

Source Pod Details:
- Image: [IMAGE_NAME]
- Container: [CONTAINER_NAME]
- Network policy applied: [YES/NO]
- Service account: [NAME]

Destination Service Details:
[PASTE: kubectl get svc [SERVICE_NAME] -n [NAMESPACE]]
[PASTE: kubectl describe svc [SERVICE_NAME] -n [NAMESPACE]]

Connectivity Test Results:
[PASTE OUTPUT OF: kubectl exec [POD] -- curl -v http://destination:port]
[PASTE OUTPUT OF: kubectl exec [POD] -- nslookup servicename]
[PASTE OUTPUT OF: kubectl exec [POD] -- ping [IP/HOSTNAME]]

Network Policies:
[PASTE: kubectl get networkpolicies -n [NAMESPACE]]

DNS Config:
[PASTE: kubectl describe configmap coredns -n kube-system]

What I've Tried:
1. [TROUBLESHOOTING STEP - RESULT]
2. [TROUBLESHOOTING STEP - RESULT]

I need:
1. Root cause of connectivity issue
2. Network policy vs service config problem analysis
3. Step-by-step fix
4. Verification commands
5. How to prevent this recurring

Format: ## Root Cause Analysis ## Network Path Validation ## Fix Steps ## Testing Checklist
```

---

### TEMPLATE 6: Resource Constraints (CPU/Memory/Disk)

**Use when**: Pod OOMKilled, CPU throttling, disk space critical  
**Model**: Sonnet  
**Time to fix**: 3-7 minutes

```
Role: I'm a DevOps engineer analyzing resource issues in Kubernetes.

Issue: Resource Constraint Problem

Type of Constraint:
- [ ] Memory (OOMKilled)
- [ ] CPU (Throttling)
- [ ] Disk (Full/Pressure)
- [ ] Storage (PVC issues)

Affected Resource:
- Pod/Node: [NAME]
- Namespace: [NAMESPACE]
- Type: [POD / NODE / PVC]

Current Resource Status:
[PASTE: kubectl top pods -n [NAMESPACE]]
[PASTE: kubectl describe pod [POD_NAME] -n [NAMESPACE]]
[PASTE: kubectl get pvc -n [NAMESPACE] -o wide]

Resource Limits Configured:
- Requests: CPU [VALUE], Memory [VALUE]
- Limits: CPU [VALUE], Memory [VALUE]

Actual Usage:
- Current: [FROM METRICS]
- Peak: [HIGHEST OBSERVED]
- Trend: [INCREASING/STABLE/DECREASING]

Pod Events:
[PASTE: kubectl describe pod [POD_NAME] | grep -A 20 Events:]

Metrics from Prometheus/Grafana:
[IF AVAILABLE: paste historical usage data]

What I've Tried:
1. [ACTION - RESULT]
2. [ACTION - RESULT]

Questions:
- Should I increase limits or optimize code
- Is this normal/expected or anomaly
- How much headroom needed

I need:
1. Is this a resource problem or application problem
2. Recommended resource allocation
3. Optimization strategies
4. Monitoring/alerting thresholds to prevent
5. Whether to scale cluster or pods

Format: ## Problem Analysis ## Recommended Allocation ## Optimization Strategies ## Monitoring Setup
```

---

### TEMPLATE 7: Log Analysis & Performance Optimization

**Use when**: Debugging through logs, optimizing slow queries  
**Model**: Sonnet (or Opus for complex issues)  
**Time to fix**: 5-15 minutes

```
Role: I'm a DevOps engineer analyzing logs for performance issues.

Analysis Request: Log Analysis / Performance Optimization

Context:
- Application: [APP_NAME]
- Timeframe: [WHEN ISSUE OCCURRED]
- Severity: [CRITICAL / HIGH / MEDIUM]
- Impact: [SLOW RESPONSE / HIGH ERROR RATE / CRASHES / METRIC ANOMALY]

Log Sample:
[PASTE: 30-50 lines of relevant logs with timestamps]

Application Logs From:
- [ ] Pod logs (kubectl logs)
- [ ] Application output
- [ ] Syslog
- [ ] Custom logging

What You're Seeing:
[DESCRIBE THE PATTERNS YOU NOTICE]

Relevant Metrics (if available):
- Response time: [VALUE]
- Error rate: [VALUE]
- Throughput: [VALUE]
- Resource usage: [VALUE]

Questions You Want Answered:
1. [QUESTION]
2. [QUESTION]
3. [QUESTION]

Context About The System:
- Expected behavior: [DESCRIBE]
- Recent changes: [NONE / LIST CHANGES]
- Scale/load: [TRAFFIC VOLUME, NUM REQUESTS]
- Data volume: [SIZE OF DATASET]

I need:
1. What's happening in these logs (step by step)
2. Root cause of the performance issue
3. Specific lines that indicate the problem
4. Optimization recommendations
5. Monitoring/alerting rules to catch this

Format: ## Log Timeline ## Root Cause ## Specific Problem Lines ## Optimization Recommendations ## Alerting Rules
```

**Example log input:**
```
2024-08-29T14:23:01.234Z [INFO] Request started: user_id=123, endpoint=/api/payment
2024-08-29T14:23:02.456Z [DEBUG] Database connection pool: available=8, used=2
2024-08-29T14:23:03.789Z [WARN] Database query slow: duration=5234ms, query=SELECT...
2024-08-29T14:23:04.012Z [ERROR] Connection timeout: service=postgres, timeout=5000ms
2024-08-29T14:23:04.345Z [ERROR] Request failed: user_id=123, error=connection_refused
2024-08-29T14:23:04.678Z [INFO] Circuit breaker opened for postgres service
```

---

## Quick Copy-Paste Guide {#quick-reference}

### One-Liners for Quick Issues

**Quick pod troubleshooting:**
```
As a DevOps engineer, my [POD_NAME] pod is [PROBLEM]. Last restart: [TIME]. Error: [COPY DESCRIBE OUTPUT]. I've tried [LIST ATTEMPTS]. What's the fix?
```

**Quick cluster check:**
```
AKS cluster [NAME] is [PROBLEM]. Nodes: [PASTE: kubectl get nodes]. Pods: [PASTE: kubectl get pods -A | grep -v Running]. Metrics: [PASTE TOP]. Root cause?
```

**Quick alert check:**
```
Alert [ALERT_NAME] is [misfiring/not firing]. Query: [PASTE QUERY]. Targets: [PASTE TARGET STATUS]. Expected: [WHAT SHOULD HAPPEN]. Why is it [failing/not alerting]?
```

---

## Pro Tips for Wibey CLI Usage

### Tip 1: Save Output to File
```bash
wibey chat --model sonnet "[TEMPLATE]" > incident_analysis.txt
```

### Tip 2: Use for Batch Analysis
```bash
# Analyze multiple pods at once
for pod in $(kubectl get pods -n prod -o name); do
  wibey chat --model haiku "Analyze this: kubectl describe $pod"
done
```

### Tip 3: Chain Claude Requests
```bash
# First: Get diagnosis
DIAGNOSIS=$(wibey chat --model sonnet "[TEMPLATE WITH ERROR]")

# Then: Get fix based on diagnosis
wibey chat --model sonnet "Based on this diagnosis: $DIAGNOSIS, give me step-by-step fix"
```

### Tip 4: Use for Runbook Generation
```bash
wibey chat --model sonnet "Create a runbook for: [YOUR INCIDENT PATTERN]"
```

---

## When to Use Which Model via Wibey

| Scenario | Model | Reason |
|----------|-------|--------|
| Quick pod status check | Haiku | Fast, simple parsing |
| Troubleshooting incident | Sonnet | Balanced depth & speed |
| Complex distributed issue | Opus | Deep reasoning needed |
| Code/script generation | Sonnet | Good code quality, fast |
| Educational explanation | Sonnet | Clear, detailed explanations |

---

## Customization Notes

- **Add your team's standards** to these templates
- **Add your common issues** not listed above
- **Replace placeholder values** with your actual cluster/namespace names if you want reusable versions
- **Combine templates** if your issue spans multiple categories

---

## Next Steps

1. **Test each template** with one real incident
2. **Note which templates work best** for your common issues
3. **Refine templates** based on what works
4. **Share with team** if helpful
5. **Build a library** of incident solutions over time

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2024-08-29 | Initial 7 templates |

---

**Questions?** Modify these templates to match your specific setup, team standards, and incident patterns.

Happy troubleshooting! 🚀
