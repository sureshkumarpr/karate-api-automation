# AI TOOLS GUIDE: Using Claude, Copilot & Alternatives
## For DevOps/Production Support at Walmart via TCS

**Context**: You have access to:
- ✅ Wibey CLI with Claude (Haiku, Sonnet, Opus)
- ✅ GitHub Copilot (if Walmart/GitHub Enterprise has it)
- ❌ Limited external tools (n8n, NotebookLM, Napkin) due to security/compliance

---

## WHAT ARE THESE 5 TOOLS?

### 01. n8n.io - Workflow Automation
**What it does**: Build workflows to connect apps without coding
- Automates repetitive tasks across systems
- Connects APIs together
- Replaces manual click-and-paste work
- Example: "When alert fires in Prometheus → Create ServiceNow ticket → Send Slack message"

**Status at Walmart**: ❌ Likely blocked (external SaaS)

**Walmart Alternative**: 
```
Use: Python scripts via Wibey Claude + ServiceNow REST API + Slack API
Instead of visual workflows, Claude helps you write the Python
```

---

### 02. NotebookLM - AI-Powered Document Analysis
**What it does**: Upload documents → AI reads and answers questions
- Takes PDFs, docs, webpages
- Creates study guides
- Generates audio summaries
- Example: "Read this 50-page incident report → Tell me patterns"

**Status at Walmart**: ❌ Blocked (external Google product, data security concerns)

**Walmart Alternative**:
```
Use: Wibey Claude to analyze documents directly
Upload file content → Claude analyzes → Get insights
```

---

### 03. Claude - AI Assistant (Your Main Tool!)
**What it does**: Chat-based AI for reasoning, coding, analysis
- Code generation and review
- Technical documentation
- Problem-solving
- Content creation

**Status at Walmart**: ✅ AVAILABLE via Wibey CLI
- You already have Haiku, Sonnet, Opus models
- This is your primary tool for everything

---

### 04. GitHub Copilot - AI Code Assistant
**What it does**: AI-powered code completion in VS Code/IDEs
- Auto-complete code while typing
- Generate functions from comments
- Explain code
- Suggest improvements

**Status at Walmart**: ✅ Possibly available (depends on GitHub Enterprise setup)
- If you have access: Use for development
- If not: Use Wibey Claude to generate full scripts

---

### 05. Napkin - Diagrams with AI
**What it does**: Create diagrams, flowcharts, architecture drawings
- Text-to-diagram
- Whiteboard sketches
- Visual explanations
- Example: "Draw Kubernetes deployment architecture"

**Status at Walmart**: ❌ Blocked (external SaaS)

**Walmart Alternative**:
```
Use: Claude to generate SVG/Mermaid diagrams
Ask Claude to create ASCII art or code for diagrams
```

---

## YOUR ACTUAL TOOLKIT (WALMART APPROVED)

### ✅ AVAILABLE TOOLS

```
┌─────────────────────────────────────────┐
│  1. WIBEY CLI (Primary - Use Every Day) │
│     • Haiku (fast)                      │
│     • Sonnet (best balance)             │
│     • Opus (most capable)               │
│                                         │
│  2. GITHUB COPILOT (If Available)       │
│     • Code generation in VS Code        │
│     • Real-time code suggestions        │
│                                         │
│  3. INTERNAL TOOLS                      │
│     • ServiceNow API                    │
│     • Jira API                          │
│     • Slack API                         │
│     • Email (SMTP)                      │
│     • Custom REST APIs                  │
└─────────────────────────────────────────┘
```

---

## TOOL-BY-TOOL: HOW TO REPLACE THEM

### TOOL 1: n8n.io (Workflow Automation)

**What n8n Does**:
```
Alert Fires → Create Ticket → Send Notification → Update Dashboard
(visual no-code workflow)
```

**How to do it with Wibey Claude**:

```bash
# Use Claude to generate Python script that does the same thing
wibey chat --model sonnet "
Write a Python script that:
1. Listens for Prometheus alerts (webhook endpoint)
2. Creates ServiceNow ticket with alert details
3. Sends Slack message to #incidents channel
4. Updates status page

Requirements:
- Use requests library for REST APIs
- ServiceNow endpoint: [YOUR_INSTANCE].service-now.com
- Slack webhook: [YOUR_WEBHOOK]
- Prometheus webhook endpoint: localhost:5000

Include error handling and logging.
"
```

**Output**: Complete Python script that runs as:
```bash
python alert_automation.py
# Or run in Docker container
```

**Advantages**:
- ✅ Runs on Walmart network (no external SaaS)
- ✅ Full control over logic
- ✅ Can integrate with internal systems
- ✅ Security compliant

---

### TOOL 2: NotebookLM (Document Analysis)

**What NotebookLM Does**:
```
Upload 50-page incident report → Get summary + key learnings + Q&A
```

**How to do it with Wibey Claude**:

```bash
# Copy document content and ask Claude to analyze
wibey chat --model sonnet "
Analyze this incident report and provide:

1. Executive Summary (3 sentences)
2. Root Cause (specific technical details)
3. Impact (what affected)
4. Timeline (when events occurred)
5. Lessons Learned (5 key takeaways)
6. Prevention (how to avoid next time)
7. Similar Past Incidents (patterns you notice)

Document:
[PASTE ENTIRE DOCUMENT HERE]

Format as Markdown with clear sections.
"
```

**Better Approach - Full Document Workflow**:

```bash
# Create file with document content
cat incident_report.txt | wibey chat --model sonnet "
Act as incident analyst. Read this incident report.

Then answer these questions:
1. What went wrong technically?
2. Who should have been notified?
3. What systems were affected?
4. How long was recovery?
5. What monitoring was missing?
6. What operational changes are needed?

Format responses with [QUESTION]...[ANSWER] pairs.
"
```

**Follow-up Questions**:
```bash
# Claude remembers context, ask follow-ups
wibey chat --model sonnet "
Based on the incident you just analyzed:
- What are the 3 most important prevention measures?
- How would you test the fixes?
- Should we change our alerting?
"
```

---

### TOOL 3: Claude (You Have This!)

**Your Primary Tool - Already Configured**

```bash
# Code generation
wibey chat --model sonnet "Write a Python script to..."

# Analysis
wibey chat --model sonnet "Analyze these logs: [logs]"

# Documentation
wibey chat --model sonnet "Create runbook for..."

# Learning
wibey chat --model sonnet "Explain Kubernetes networking..."
```

---

### TOOL 4: GitHub Copilot (Conditional)

**If Available at Your Company**:

✅ **In VS Code / GitHub**: Real-time code suggestions as you type
✅ **Faster coding**: Completes functions from comments
✅ **Built into IDE**: Seamless workflow

**Check Availability**:
```bash
# If you have GitHub Enterprise access
# And VS Code Copilot extension installed
→ You can use it directly in IDE
```

**If NOT Available - Use Wibey Instead**:

```bash
# Ask Claude to generate full files
wibey chat --model sonnet "
Generate a complete Python function file for:
[Describe what you need]

Include:
- Proper error handling
- Type hints
- Docstrings
- Unit tests
"

# Then copy-paste into VS Code
```

---

### TOOL 5: Napkin (Diagrams)

**What Napkin Does**:
```
"Draw a Kubernetes deployment architecture"
↓
Automatic diagram/flowchart generated
```

**How to do it with Claude**:

#### Option A: Generate ASCII Art (Instant)
```bash
wibey chat --model haiku "
Draw ASCII diagram of Kubernetes cluster with:
- 3 worker nodes
- Load balancer
- Pods running microservices
- Persistent volumes
- Ingress controller

Use box drawing characters (┌─┐│└┘).
"
```

**Output**:
```
┌────────────────────────────────────────────┐
│          Kubernetes Cluster                │
├────────────────────────────────────────────┤
│                                            │
│  ┌─────────────┐  ┌─────────────┐        │
│  │  Worker 1   │  │  Worker 2   │        │
│  │ ┌─────────┐ │  │ ┌─────────┐ │        │
│  │ │Pod1 Svc │ │  │ │Pod2 Svc │ │        │
│  │ └─────────┘ │  │ └─────────┘ │        │
│  └─────────────┘  └─────────────┘        │
│         ▲                ▲                │
│         └────┬───────────┘                │
│              │                            │
│         ┌────▼────┐                       │
│         │Ingress  │                       │
│         │Load Bal │                       │
│         └─────────┘                       │
│                                            │
└────────────────────────────────────────────┘
```

#### Option B: Generate Mermaid Diagram (Better for Docs)
```bash
wibey chat --model sonnet "
Generate a Mermaid diagram showing:
- Incident workflow
- Alert → Diagnosis → Fix → Verification
- With decision points
- Include escalation path

Output ONLY the Mermaid code (graph TD format).
"
```

**Output**:
```mermaid
graph TD
    A[Alert Fired] --> B{Auto-Fixable?}
    B -->|Yes| C[Apply Auto-Fix]
    B -->|No| D[Create Ticket]
    C --> E{Verified?}
    E -->|Yes| F[Resolved]
    E -->|No| D
    D --> G[Assign to On-Call]
    G --> H[Diagnose]
    H --> I[Implement Fix]
    I --> J[Verify]
    J --> F
```

#### Option C: Generate SVG Diagram (Embeddable)
```bash
wibey chat --model sonnet "
Generate SVG code for a flowchart showing:
[Your requirement]

The SVG should:
- Be valid and renderable
- Use basic shapes (rectangles, circles, lines)
- Be around 400x300 pixels
- Include labels

Output ONLY the <svg>...</svg> code.
"
```

---

## COMPLETE WORKFLOW: HOW TO USE ALL TOOLS TOGETHER

### Scenario: Automate Incident Response

```
GOAL: When pod crashes → Auto-create ticket, notify team, run diagnostic

┌─────────────────────────────────────────────────────────────────┐
│ STEP 1: Design Workflow (Napkin Alternative)                   │
├─────────────────────────────────────────────────────────────────┤
│ wibey chat --model haiku "                                      │
│ Draw workflow for:                                              │
│ Pod Crash → Alert → Diagnosis → Auto-fix/Escalate              │
│ "                                                               │
│                                                                 │
│ ✓ Get ASCII diagram to visualize flow                          │
└─────────────────────────────────────────────────────────────────┘
         ↓
┌─────────────────────────────────────────────────────────────────┐
│ STEP 2: Write Automation Script (Claude/Copilot)               │
├─────────────────────────────────────────────────────────────────┤
│ wibey chat --model sonnet "                                     │
│ Generate Python webhook receiver that:                          │
│ 1. Gets Prometheus alert                                        │
│ 2. Runs 'kubectl describe' to get details                      │
│ 3. Creates ServiceNow incident                                  │
│ 4. Sends to Slack #incidents                                   │
│ 5. Stores in database for analytics                            │
│ "                                                               │
│                                                                 │
│ ✓ Get complete working Python script                           │
└─────────────────────────────────────────────────────────────────┘
         ↓
┌─────────────────────────────────────────────────────────────────┐
│ STEP 3: Deploy & Run (n8n Alternative)                         │
├─────────────────────────────────────────────────────────────────┤
│ # Save script locally                                           │
│ python incident_automation.py                                   │
│                                                                 │
│ # Or run in container                                           │
│ docker run -e SLACK_WEBHOOK=xxx myincident:latest              │
│                                                                 │
│ ✓ Automation running on your cluster                           │
└─────────────────────────────────────────────────────────────────┘
         ↓
┌─────────────────────────────────────────────────────────────────┐
│ STEP 4: Document & Learn (NotebookLM Alternative)               │
├─────────────────────────────────────────────────────────────────┤
│ wibey chat --model sonnet "                                     │
│ [Paste all incidents from past month]                          │
│                                                                 │
│ Analyze and provide:                                            │
│ - Most common root causes                                       │
│ - Patterns in timing                                            │
│ - Services most affected                                        │
│ - Preventive measures recommended                               │
│ "                                                               │
│                                                                 │
│ ✓ Get insights and patterns                                    │
└─────────────────────────────────────────────────────────────────┘
```

---

## YOUR TOOL STACK: RECOMMENDED SETUP

### Tier 1: Daily Use (Primary)
```
┌──────────────────────────────────────┐
│  WIBEY CLI (Claude Sonnet)           │
│  ├─ Code generation                  │
│  ├─ Analysis & troubleshooting        │
│  ├─ Documentation                     │
│  ├─ Automation scripts                │
│  └─ Learning & explanations           │
└──────────────────────────────────────┘
```

**Usage**:
```bash
# Nearly every incident
wibey chat --model sonnet "[TEMPLATE or QUESTION]"

# Quick checks
wibey chat --model haiku "Is my pod healthy?"

# Complex analysis
wibey chat --model opus "Deep analysis of..."
```

---

### Tier 2: Active Development (Secondary)
```
┌──────────────────────────────────────┐
│  GITHUB COPILOT (If Available)       │
│  ├─ Real-time code completion        │
│  ├─ IDE integration                   │
│  └─ Developer experience              │
└──────────────────────────────────────┘
```

**Usage**:
```
In VS Code:
1. Start typing function signature
2. Copilot suggests implementation
3. Accept with Tab
4. Continue coding with AI help
```

---

### Tier 3: On-Demand (As Needed)
```
┌──────────────────────────────────────┐
│  INTERNAL TOOLS                      │
│  ├─ ServiceNow REST API               │
│  ├─ Jira REST API                     │
│  ├─ Slack API                         │
│  ├─ Prometheus API                    │
│  └─ Custom internal APIs              │
└──────────────────────────────────────┘
```

**Usage**:
```bash
# Claude generates code that calls these APIs
wibey chat --model sonnet "
Generate Python script to:
- Query ServiceNow incidents from past 24 hours
- Group by category
- Send summary to Slack
- Include: Count, avg duration, top services
"
```

---

## SPECIFIC PROMPTS FOR YOUR USE CASES

### Use Case 1: Automate Alert Response (n8n Replacement)

```bash
wibey chat --model sonnet "
I need Python code that:
1. Runs as Flask webhook server
2. Receives Prometheus alert webhooks
3. For pod crash alerts:
   - Runs: kubectl describe pod [pod]
   - Creates ServiceNow incident with details
   - Posts to Slack: #incident-alerts
   - Stores in PostgreSQL for analytics

Include:
- Error handling for API failures
- Retry logic for transient errors
- Logging to file
- Configuration via environment variables
- Docker-ready

Required APIs:
- ServiceNow: [your-instance].service-now.com/api/now
- Slack: [your-webhook-url]
- Prometheus: [your-prometheus-url]
"
```

---

### Use Case 2: Analyze Incidents (NotebookLM Replacement)

```bash
# Collect incidents
for i in $(seq 1 100); do
  curl https://your-incident-db/incident/$i >> incidents.txt
done

# Ask Claude to analyze
wibey chat --model sonnet "
Analyze these 100 incidents and provide:

1. Root Cause Analysis
   - Most common causes
   - By service/component
   
2. Temporal Patterns
   - Time of day patterns
   - Day of week patterns
   
3. Impact Analysis
   - Avg duration to fix
   - Services most affected
   
4. Recommendations
   - Top 5 prevention measures
   - Automation opportunities
   - Alert improvements
   
5. Process Improvements
   - Where do we get stuck?
   - Better runbooks needed?
   - Skills gaps?

Incidents:
[PASTE INCIDENTS]

Format: Markdown with clear sections and data tables.
"
```

---

### Use Case 3: Generate Architecture Diagram (Napkin Replacement)

```bash
wibey chat --model sonnet "
Generate a Mermaid diagram for our Kubernetes architecture:

Components:
- 2 AKS clusters (prod, staging)
- Each cluster has: API gateway, auth service, payment service, notifications
- Shared: PostgreSQL database, Redis cache, Prometheus monitoring
- External: Slack, ServiceNow, GitHub

Show:
- Service dependencies
- Data flow
- External integrations

Output: ONLY Mermaid code (graph TD format)
"
```

---

### Use Case 4: Create Automation Script (Copilot Replacement)

```bash
# If Copilot not available, use Claude to generate full file
wibey chat --model sonnet "
Create a complete Python file 'deploy_app.py' that:

Functions needed:
1. get_deployment_status(app_name, namespace)
   - Queries kubectl
   - Returns: ready/not_ready/error
   
2. run_health_check(app_url, expected_code=200)
   - Checks endpoint responds
   - Returns: True/False
   
3. trigger_deployment(app_name, namespace, image_tag)
   - Updates image tag in deployment
   - Waits for rollout
   - Runs health check
   
4. rollback(app_name, namespace)
   - Rolls back to previous revision

Include:
- Type hints for all functions
- Proper docstrings
- Error handling
- Logging
- Command-line argument parsing

Output: Complete, ready-to-run Python file.
"
```

---

## COMPLIANCE & SECURITY CONSIDERATIONS

### ✅ SAFE (Walmart Approved)

```
• Wibey CLI (internal Anthropic API)
• GitHub Copilot (GitHub Enterprise, if available)
• Internal APIs (ServiceNow, Jira, Slack via official APIs)
• Local scripts generated by Claude
• Docker containers running locally
```

### ❌ NOT SAFE (Likely Blocked)

```
• External SaaS (n8n, Napkin - unless company approved)
• Public cloud storage of data
• Uploading company data to external services
• Public GitHub repos with internal code
• Unencrypted API keys in code
```

### Best Practice - Generated Scripts

```bash
# DO: Use environment variables for secrets
export SLACK_WEBHOOK=$SLACK_WEBHOOK_URL
export SERVICE_NOW_KEY=$SN_API_KEY

python automation_script.py

# DON'T: Hardcode secrets
# BAD: api_key = "xsec-12345-xxxxx"
```

---

## ACTION PLAN FOR YOUR TEAM

### Week 1: Setup
- [ ] Map out your automation needs
- [ ] Identify which n8n/NotebookLM tasks you need
- [ ] Get Claude/Copilot access approved
- [ ] Test basic Wibey CLI workflows

### Week 2: Build Automation
- [ ] Generate first automation script with Claude
- [ ] Test locally in Docker
- [ ] Deploy to staging cluster
- [ ] Validate with real alerts

### Week 3: Scale & Learn
- [ ] Analyze incident patterns with Claude
- [ ] Refine automation based on learnings
- [ ] Document processes
- [ ] Train team on new workflows

### Month 2+: Continuous Improvement
- [ ] Monthly incident analysis with Claude
- [ ] Identify new automation opportunities
- [ ] Refine runbooks and documentation
- [ ] Build knowledge base

---

## QUICK REFERENCE: WIBEY COMMANDS

### Daily Use
```bash
# Troubleshoot incident
wibey chat --model sonnet "$(cat TEMPLATE_1_K8S_POD_CRASH.txt)"

# Quick analysis
wibey chat --model haiku "Status check: [data]"

# Deep complex issue
wibey chat --model opus "Complex analysis: [data]"

# Generate script
wibey chat --model sonnet "Create Python function for..."

# Save output
wibey chat --model sonnet "[PROMPT]" > output.txt
```

---

## FINAL SUMMARY

| Tool | What It Does | Walmart Status | Alternative |
|------|-------------|---|---|
| n8n.io | Workflow automation | ❌ Blocked | Claude → Python script |
| NotebookLM | Document analysis | ❌ Blocked | Claude → Direct analysis |
| Claude | AI assistant | ✅ AVAILABLE | Use Wibey CLI daily |
| Copilot | Code completion | ✅ Probably available | Use Claude if not |
| Napkin | Diagram generation | ❌ Blocked | Claude → ASCII/Mermaid |

**Bottom Line**: You have everything you need via Wibey Claude + potential GitHub Copilot. You don't need the blocked tools!

---

**Ready to build automation?** Ask me to generate specific scripts for your needs!
